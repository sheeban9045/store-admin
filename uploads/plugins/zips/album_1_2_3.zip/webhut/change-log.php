
<!--header-->
<!DOCTYPE html>
<html lang="en">


<head>
    <title>Matt Community</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no, minimal-ui" />
    <link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="images/logo/icon.png" />
    <link rel="stylesheet" href="css/css-library/bootstrap.min.css">
    <link rel="stylesheet" href="css/css-library/icon-font.css">
    <link rel="stylesheet" href="css/css-library/welcome.css">
    <link rel="stylesheet" href="css/style7e0c.css?v=0.1">
</head>

<body>
<div id="home">

        <section class="top-header">
            <div class="container-fluid">
                <div class="row">

                     <div class="col-md-6">
                        <div class="left-menu">
                            <ul class="text-left mb-0">
                                <li> 
                                    <a class="nav-link" href="emailto:abc@example.com"><i class="fa fa-envelope-o"></i> abc@example.com</a>
                                </li>
                                <li> 
                                    <a class="nav-link" href="tel:+99 9876543210"><i class="fa fa-phone"></i> +99 9876543210</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-6 col-12">
                        <div class="left-menu">
                            <ul class="text-right mb-0">
                                <li> 
                                    <a class="nav-link" href="https://www.questwalktech.com/matt-subscription/store-admin/index.php/signin">Login</a>
                                </li>
                                <li> 
                                    <a class="nav-link" href="https://www.questwalktech.com/matt-subscription/store-admin/index.php/signup">Register</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <nav id="navbar" class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index-2.php">
                    <img src="images/logo/logo.png" height="" width="180" alt="Matt Community">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#site-nav" aria-controls="site-nav" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="site-nav">
                    <ul class="navbar-nav text-sm-left ml-auto">
                        <li class="nav-item"> 
                            <a class="nav-link" href="index-2.php">Home</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" data-toggle="dropdown">Features 
                                <span class="pe-2x pe-7s-angle-down"></span>  
                            </a>
                            <div class="dropdown-menu"> 
                                <a class="dropdown-item" href="comparison-table.php">Features Plan Comparison</a>
                                <!-- <a class="dropdown-item" href="#">Earn More Money</a>
                                <a class="dropdown-item" href="#">Instant Messaging</a>
                                <a class="dropdown-item" href="#">All payment methods are supported!</a>
                                <a class="dropdown-item" href="#">Powerful Live Streaming</a> -->
                            </div>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="pricing.php">Pricing</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="#">Plugins</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="contact.php">FAQ</a>
                        </li>
                        <li class="nav-item dropdown"> 
                            <a class="nav-link" href="#" data-toggle="dropdown">More 
                                <span class="pe-2x pe-7s-angle-down"></span>  
                            </a>
                            <div class="dropdown-menu"> 
                                <a class="dropdown-item" href="contact.php">Customization</a>
                                <a class="dropdown-item" href="contact.php">Documentation</a>
                                <a class="dropdown-item" href="contact.php">Change Log</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="btn align-middle btn-outline-light my-2 my-lg-0">Demo</a>
                        </li>
                         <a href="pricing.php" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>

<section class="jumbotron text-center">
      
            <div class="container">
                <h1 class="display_4 vhid wow fadeInUp pure_white" style="visibility: visible; animation-name: fadeInUp;">Matt Community Change Log</h1>
                <p class="vhid wow fadeIn" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;">
                     <a href="#pricing" class="btn btn-lg btn-light">Get Matt Community</a>
                    <a href="#" class="btn btn-lg btn-outline-light" target="_blank">See Demo</a>
                </p>
            </div>
        </section>

	
	<!--Features-->
	<div class="section">
		<div class="container">
			<h3 class="display_5">Latest Updates</h3>
			<p>Matt Community is regularly updated, view the latest updates below.</p>
			<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.2.2 <small>09 Augest 2021 </small></h6>
                            <ul>
                                <li> [Added] Palestine to country list.</li>
                                <li> [Removed] dublicated nginx rules in nginx.conf, update required for nginx users. </li>
                                <li> [Replaced] Yahoo weather with new provider https://openweathermap.org</li>
                                <li> [Fixed] live video not working on firefox.</li>
                                <li> [Fixed] blog point issue, user will get points now after approving.</li>
                                <li> [Fixed] nearby shops counter. </li>
                                <li> [Fixed] line break issue in nodejs chat system.</li>
                                <li> [Fixed] refund page wasn't apearing. </li>
                                <li> [Fixed] add movies page in admin, sometimes it looks broken.</li>
                                <li> [Fixed] bank details wasn't getting updated in admin panel. </li>
                                <li> [Fixed] issues in desgin.</li>
                                <li> [Fixed] video post on MySQL 8 and PHP 8.</li>
                                <li> [Fixed] more minor bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.2.1 <small>28 June 2021 </small></h6>
                            <ul>
                                <li> [Added] delete account E-mail to Manage Emails in admin panel.</li>
                                <li> [Re-orginzed] admin panel links, content, texts and created auto save system.</li>
                                <li> [Fixed] seen issue on nodejs.</li>
                                <li> [Fixed] FTP support on nodejs.</li>
                                <li> [Fixed] "View X Posts" on newsfeed (NodeJS).</li>
                                <li> [Fixed] 2 security issues (important). </li>
                                <li> [Fixed] double points when posting multi images.</li>
                                <li> [Fixed] 500 Error when accessing a page without being logged in. </li>
                                <li> [Fixed] URL fetcher, it wasn't fetching URLs from Matt Community blogs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.2 <small>8 June 2021 </small></h6>
                            <ul>
                                <li> [Added] ability to edit and translate emails from admin panel, under Tools > Manage E-mails.</li>
                                <li> [Added] expire time for reset password links, 12 hours.</li>
                                <li> [Added] FFMPEG for video conversation + thumbnail generation + debug ffmpeg feature from admin panel + up to 4K video support, (Enable / Disable).</li>
                                <li> [Added] auto username generator, for new user registration users are not required to write their username. (Enable / Disable)</li>
                                <li> [Added] new APIs, more than 40+.</li>
                                <li> [Added] reactions for messages, (ajax / nodejs). </li>
                                <li> [Added] reply system for messages, (ajax / nodejs). </li>
                                <li> [Added] reactions system for stories. </li>
                                <li> [Added] reply system for stories. </li>
                                <li> [Added] gifs + stickers to comment system. </li>
                                <li> [Added] gifs + stickers to reply system. </li>
                                <li> [Added] video chat by Agora. </li>
                                <li> [Added] terms of use checkbox to contact us page. </li>
                                <li> [Added] the ability to delete poll answers while creating one.</li>
                                <li> [Added] login with Mailru, Discord, WeChat and QQ.</li>
                                <li> [Added] ability to delete selected user's messages, stories, posts, articles, and notifications from admin panel.</li>
                                <li> [RE-ADDED] script version in admin panel sidebar.</li>
                                <li> [Updated] twilio video chat system. </li>
                                <li> [Updated] message seen systemn (NodeJS). </li>
                                <li> [Fixed] 80+ reported bugs and improvments.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.1.3 <small>12 April 2021 </small></h6>
                            <ul>
                                <li> [Added] real-time notification system.</li>
                                <li> [Improved] server load & site speed.</li>
                                <li> [Removed] All PHP ajax intervals, requests, and loops from clinet end (if nodejs enabled) and replaced to realtime web socket.</li>
                                <li> [Fixed] 3+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.1.2 <small>28 March 2021 </small></h6>
                            <ul>
                                <li> [Added] support for PHP 8.0+ and MySQL 8.0</li>
                                <li> [Added] new ajax load system for admin panel, now admin panel pages are loaded thru ajax.</li>
                                <li> [Updated] nodejs chat system, now users can see typing action on messages user list, real time avatar update, name, and status.</li>
                                <li> [Updated] S3 / Spaces libraries. </li>
                                <li> [Improved] speed on PHP 8.0</li>
                                <li> [Fixed] 20+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.1.1 <small>05 March 2021 </small></h6>
                            <ul>
                                <li> [Fixed] 10+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.1 <small>04 March 2021 </small></h6>
                            <ul>
                                <li> [Added] new messaging system powered by NodeJS and websockets, now chat are faster, real time, and smoother. </li>
                                <li> [Added] new admin panel v2, with many options.</li>
                                <li> [Added] new timestamp system, e.g (1 mintue ago -> 1 m, 2 hours ago -> 2 hrs, 1 month ago -> 4 w, 1 year ago -> 1 y)</li>
                                <li> [Added] new notifications for admin panel, now you'll get notificed for any new bank payments, verfication requests and more.</li>
                                <li> [Added] night mode to admin panel. </li>
                                <li> [Improved] security. [Important] </li>
                                <li> [Fixed] 60+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.0.3 <small>08 July 2020 </small></h6>
                            <ul>
                               <li> [Added] ability to embed posts from TikTok, Twitter, and MP4 links. </li>
                                <li> [Improved] security. [Important] </li>
                                <li> [Fixed] 10+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.0.3 <small>08 July 2020 </small></h6>
                            <ul>
                                <li> [Added] ability to choose camera on live streaming. </li>
                                <li> [Added] thumbnail for live streaming videos. </li>
                                <li> [Added] female avatar for female users. </li>
                                <li> [Added] Few more APIs. (payment methods) </li>
                                <li> [Fixed] 20+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.0.2
                                <small>26 May 2020 </small></h6>
                            <ul>
                                <li> [Added] Agora Live Streaming. </li>
                                <li> [Added] Few more APIs. </li>
                                <li> [Fixed] 40+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                                <li> [Improved] Load speed.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.0.1
                                <small>18 April 2020 </small></h6>
                            <ul>
                                <li> [Fixed] 10+ bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v3.0
                                <small>16 April 2020 [Ultimate] </small></h6>
                            <ul>
                                <li> [Added] the ability to edit/add/disable post reactions. </li>
                                <li> [Added] memories system, user can view his memories on this day.</li>
                                <li> [Added] live stream for posts [enable/disable] (third party sites).</li>
                                <li> [Added] page analytics, view latest likes per week, month, year, and today.</li>
                                <li> [Added] group analytics, view latest joins per week, month, year, and today.</li>
                                <li> [Added] blog post notifications, get a notification when someone comments on your blog post.</li>
                                <li> [Added] forum notifications, get a notification when someone comments on your forum thread.</li>
                                <li> [Added] the ability to require membership on sign up, [enable/disable]</li>
                                <li> [Added] sub categories for pages, groups and marketplace.</li>
                                <li> [Added] custom fields for pages, groups and marketplace. </li>
                                <li> [Added] remaining pro membership days announcement. </li>
                                <li> [Added] recurring payments for pro system.</li>
                                <li> [Added] the ability for only pro users could upload [enable/disable].</li>
                                <li> [Added] the ability for only pro users could make calls [enable/disable]</li>
                                <li> [Added] blog posts review/approval system. </li>
                                <li> [Added] the ability to request refund for pro package [enable/disable]</li>
                                <li> [Added] refund policy page. </li>
                                <li> [Added] paystack, razorpay, paysera and cashfree payment methods. </li>
                                <li> [Added] page to show shops/businesses nearby. </li>
                                <li> [Added] offer system for pages. </li>
                                <li> [Added] password complexity system on register page. </li>
                                <li> [Added] prevent brutforce on login system, limit failed login per min.</li>
                                <li> [Added] the ability for users to be able to post in the pages. [enable/disable]</li>
                                <li> [Added] the ability for pages and groups owners could add moderators with certain privileges.</li>
                                <li> [Added] google cloud for storage.</li>
                                <li> [Added] bank account withdrawal method, user can send his bank info to admin and admin can review then approve.</li>
                                <li> [Added] email mock system. send email for users who didn't login for X time.</li>
                                <li> [Added] the ability to add games from other sites, not just miniclip.</li>
                                <li> [Added] the ability to get notified when user posts new post.</li>
                                <li> [Added] ads within and inside articles.</li>
                                <li> [Added] the ability for users to generate invite links.</li>
                                <li> [Added] shout box, post anonymously.</li>
                                <li> [Added] the ability to get notified when a friend posts a new post.</li>
                                <li> [Fixed] 50+ bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                                <li> [Fixed] Important security issues.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.5.2
                                <small>7 Jan 2020 [Important]</small></h6>
                            <ul>
                                <li> [Added] click button to comment and reply.</li>
                                <li> [Fixed] bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                                <li> [Fixed] Important security issues.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.5.1
                                <small>17 Dec 2019 [Important]</small></h6>
                            <ul>
                                <li> [Added] view joined groups and liked pages from one page.</li>
                                <li> [Added] the ability to attache photos in commment replies.</li>
                                <li> [Added] missing files from v2.5</li>
                                <li> [Fixed] bugs in API.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.5
                                <small>16 Dec 2019 [Script improvments update]</small></h6>
                            <ul>
                                <li> [Added] the ability logout from all sessions.</li>
                                <li> [Added] the ability to approve or decline a post, enable / disable.</li>
                                <li> [Added] new APIs. </li>
                                <li> [Added] auto like for pages and auto join for groups. </li>
                                <li> [Updated] PHP libaries.</li>
                                <li> [Updated] Google login API.</li>
                                <li> [Improved] default theme desgin.</li>
                                <li> [Improved] speed.</li>
                                <li> [Improved] english in some parts.</li>
                                <li> [Fixed] 100+ reported bugs and issues.</li>
                                <li> [Fixed] bugs in API.</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.4
                                <small>01 Sep 2019</small></h6>
                            <ul>
                                <li> [Added] the ability to send messages to pages.</li>
                                <li> [Added] the ability to accept or decline a group chat invitation.</li>
                                <li> [Added] job system, users can now create jobs and hire.</li>
                                <li> [Added] weather plugin to sidebar. </li>
                                <li> [Added] common things page, now you can find users that matches your information.</li>
                                <li> [Added] funding system, users can create funds, and get paid.</li>
                                <li> [Added] new APIs. </li>
                                <li> [Fixed] 20+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                                <li> [Improved] speed.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.3.3
                                <small>11 July 2019</small></h6>
                            <ul>
                                <li> [Added] few new APIs to v2.</li>
                                <li> [Fixed] 20+ reported bugs.</li>
                                <li> [Fixed] bugs in API.</li>
                                <li> [Improved] script stabilitiy for v2.4</li>
                                <li> [Improved] speed.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.3.2
                                <small>20 June 2019</small></h6>
                            <ul>
                                <li> [Fixed] 20+ reported bugs.</li>
                                <li> [Improved] speed.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.3.1
                                <small>2 June 2019</small></h6>
                            <ul>
                                <li> [Fixed] 10+ reported bugs.</li>
                                <li> [Fixed] security issue.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.3
                                <small>30 May 2019</small></h6>
                            <ul>
                                <li> [Added] Manage currencies from admin panel, add any currency, remove, delete, one currency for all, pro, ads and market.</li>
                                <li> [Added] the ability to comment on albums, and multi images.</li>
                                <li> [Added] filter comments, top and latest. </li>
                                <li> [Added] the ability to make forums, marketplace and events public and reachable by google. </li>
                                <li> [Added] the ability to enable / disable PayPal payment method. </li>
                                <li> [Added] the ability to disable a language without deleting it. </li>
                                <li> [Added] the ability to enable / disable pokes, and "good monring" message. </li>
                                <li> [Added] the ability for users to make comment on post before sharing it. </li>
                                <li> [Added] the ability to block a domain from email while siging up, example, blocking @gmail.com </li>
                                <li> [Added] embeded product style to messages. </li>
                                <li> [Added] colored posts, with the ability to manage, add, remove and edit them. </li>
                                <li> [Added] 2Checkout payment method. </li>
                                <li> [Added] search on admin panel.</li>
                                <li> [Changed] password hash from sha1 to password_hash encryption. </li>
                                <li> [Improved] ajax speed by reducing requests.php file size and seperating the requests.</li>
                                <li> [Fixed] 20+ reported bugs.</li>
                                <li> [Fixed] API issues.</li>
                                <li> [Fixed] security issue.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.2.2
                                <small>12 April 2019</small></h6>
                            <ul>
                                <li> [Added] deepsound embed feature, now you can embed the player from deepsound to Matt Community.</li>
                                <li> [Fixed] 20+ reported bugs.</li>
                                <li> [Fixed] security issue.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.2.1
                                <small>6 April 2019</small></h6>
                            <ul>
                                <li> [Added] support for PHP 7.3+</li>
                                <li> [Fixed] 30+ reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.2
                                <small>1 April 2019</small></h6>
                            <ul>
                                <li> [Added] The ability to add and manage genders from admin panel.</li>
                                <li> [Added] The ability to earn points by creating blogs. </li>
                                <li> [Added] points daily limit for pro and free users. </li>
                                <li> [Added] The ability to edit group chat info and avatar.</li>
                                <li> [Added] The ability to turn off messages from friends or everyone.</li>
                                <li> [Added] the ability to filter porn and nude pictures using Google Vision API.</li>
                                <li> [Added] user will require to verfiy his email if he changed is from settings page, if email verfication is enabled.</li>
                                <li> [Added] new sharing system, with new style and the abiltiy to share to timeline, group and pages.</li>
                                <li> [Added] the ability to manage pro packages name, icon, features, prices, and disable which one of them</li>
                                <li> [Added] the ability to manage pages, groups, products and blog categories from admin panel > manage features + seperated.</li>
                                <li> [Added] the ability to view the reactions, likes, dislikes on comments and replies.</li>
                                <li> [Added] the ability to view reactions, likes of posts on new model.</li>
                                <li> [Added] bank payments for wallet and pro.</li>
                                <li> [Added] group chat API, albums API, Pokes API and few other APIs. </li>
                                <li> [Added] group chat notifications.</li>
                                <li> [Added] the ability to delete a user posts by one click from admin panel. </li>
                                <li> [Added] recaptcha to contact us from. </li>
                                <li> [Added] new message page desgin for default theme.</li>
                                <li> [Fixed] few important bugs.</li>
                                <li> [Fixed] secuity threat, URGENT an update is required.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.1.1
                                <small>29 January 2019</small></h6>
                            <ul>
                                <li> [Added] Download my information, user can download personal info, pages, groups, posts and friends.</li>
                                <li> [Fixed] few important bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.1
                                <small>20 January 2019</small></h6>
                            <ul>
                                <li> [Added] new theme, "sunshine".</li>
                                <li> [Added] new story system for both themes. </li>
                                <li> [Added] filter system on marketplace, on the new theme. </li>
                                <li> [Added] hashtag posts count, on new theme.</li>
                                <li> [Fixed] few bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
             </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.0.3.1
                                <small>30th Octobar 2018</small></h6>
                            <ul>
                                <li> [Fixed] few important bugs in wallet system and other major bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.0.3
                                <small>16th Octobar 2018</small></h6>
                            <ul>
                                <li> [Added] confirmation system when user login from new location. </li>
                                <li> [Added] two-factor authentication system using email or phone. </li>
                                <li> [Fixed] few bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.0.2
                                <small>9th Octobar 2018</small></h6>
                            <ul>
                                <li> [Added] new video player. </li>
                                <li> [Added] the ability to disable / enable google maps.</li>
                                <li> [Added] the ability for admin to top up any user wallet.</li>
                                <li> [Added] IP to session manager.</li>
                                <li> [Added] the ability to disable / enable comments on each post.</li>
                                <li> [Fixed] 9 reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.0.1
                                <small>5th Octobar 2018</small></h6>
                            <ul>
                                <li> [Fixed] 11 reported bugs. </li>
                                <li> [Improved] Script speed.</li>
                                <li> [Fixed] important security vulnerability.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v2.0
                                <small>30th Sep 2018</small></h6>
                            <ul>
                                

<li>[Added] digitalocean spaces storage.
</li>
<li>[Added] poke system.
</li>
<li>[Added] reaction system (Like, Haha, wow, angry, love).
</li>
<li>[Added] gift system, users can send each other gifts.
</li>
<li>[Added] statics and charts to daily ads views / clicks.
</li>
<li>[Added] Infobip to SMS providers.
</li>
<li>[Added] stripe to wallet system like on go pro page.
</li>
<li>[Added] password recovery by phone number.
</li>
<li>[Added] estimated user reach on create ads page.
</li>
<li>[Added] bitcoin (coinpayments) payment method for ads and pro system.
</li>
<li>[Added] Payment Transactions history for wallet topups and pro system, with the ability to turn this feature on or off.
</li>
<li>[Added] the option to change the phone number from settings page.
</li>
<li>[Added] popular posts page.
</li>
<li>[Added] photos & videos sections to profile.
</li>
<li>[Added] End video chat button.
</li>
<li>[Added] ability to use percentage in the affiliate system.
</li>
<li>[Added] telegram to share options.
</li>
<li>[Added] admin can disable and enable social share links.
</li>
<li>[Added] more emojies.
</li>
<li>[Added] shortkey for posts, clicking "j" to scroll to next post.
</li>
<li>[Added] points system, user can earn points for posts, comments, likes, dislikes, wonders, and reactions. (User can spend points on pro or ads, or he can requst them as dollars).
</li>
<li>[Added] stickers to chat and messages.
</li>
<li>[Added] rotate system for images.
</li>
<li>[Added] Manage developer applications from admin panel.
</li>
<li>[Added] Report comment to admin.
</li>
<li>[Added] Advanced search system for custom fields.
</li>
<li>[Added] Added filter by age, and verfied to the search system.
</li>
<li>[Added] suggested groups / pages in my groups and my pages.
</li>
<li>[Added] search system in blog.
</li>
<li>[Added] auto friend system (Auto follow / friend with new registred users).
</li>
<li>[Added] the ability to view mutual friends from the profile (friends system).
</li>
<li>[Added] the ability to know who viewed your stories via notifications.
</li>
<li>[Added] ReCaptcha check to forgot password form (secuirty).
</li>
<li>[Added] blog comment notifications.
</li>
<li>[Added] Email notification when the user's account was deleted.
</li>
<li>[Added] a warning message before unfriending someone.
</li>
<li>[Added] session manager (users can view / manage browser / platforms where they are logged in).
</li>
<li>[Added] notification management system (Users can choose what kind of notifications they want to get).
</li>
<li>[Added] the ability to add followers to a specific user using IDs, in Admin > Users (Enabled just in follow system).
</li>
<li>[Added] blacklist system, admin can blacklist emails, usernames, and IP addresses.
</li>
<li>[Added] activities system, user can view his own activities from his profile (like, dislike, react, wonder, comment, reply, follow, friends).
</li>
<li>[Added] the ability for a user to choose if their profile should be found/indexed by search engines.
</li>
<li>[Improved] load speed.
</li>
<li>[Compressed] JS files to few less files.
</li>
<li>[Fixed] bugs on API.
</li>
<li>[Fixed] major bugs in the script. (+10)
</li>
<li>[Fixed] 3 security issues.</li>


                            </ul>
                        </div>
                    </div>
                </div>
            </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.6.2
                                <small>27th Jun 2018</small></h6>
                            <ul>
                                <li> [Added] New welcome page for the default theme. </li>
                                <li> [Added] Wasabi storage support.</li>
                                <li> [Upgraded] PHPMailer to v6.</li>
                                <li> Fixed 10+ reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.6.1
                                <small>13th Jun 2018</small></h6>
                            <ul>
                                <li> [Added] Day status to default theme (good morning etc).</li>
                                <li> [Improved] wonderful theme desgin and forms.</li>
                                <li> [Improved] publisher box stability.</li>
                                <li> [Removed] Weather plugin from wonderful theme due copyright issues.</li>
                                <li> Fixed 10+ reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
              <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.6
                                <small>27th May 2018</small></h6>
                            <ul>
                                <li> [Added] FTP client server to store files, images, videos on other servers.</li>
                                <li> [Added] GDPR compliance (cookie frame, checkboxes, privacy policy)</li>
                                <li> [Added] full new APIv2 + docs.</li>
                                <li> [Added] the ability to edit movies from admin panel.</li>
                                <li> [Added] the abilty to post mobile emojies on posts, comments, and messages.</li>
                                <li> [Added] Auto delete system for users and posts that are longer than X date.</li>
                                <li> [Added] Crop system for user avatar.</li>
                                <li> Translated all page's titles.</li>
                                <li> Improved load post speed on wonderful theme.</li>
                                <li> Fixed 3 security issues.</li>
                                <li> Fixed 50+ reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.5.3
                                <small>17th April 2018</small></h6>
                            <ul>
                                <li> Added two keys for OneSignal.</li>
                                <li> Added video call API for mobile applications.</li>
                                <li> Improved the cache system for user data.</li>
                                <li> Fixed all reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.5.2
                                <small>6th April 2018</small></h6>
                            <ul>
                                <li> Improved content load and server load 50% faster.</li>
                                <li> Fixed all reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.5.1
                                <small>29th March 2018</small></h6>
                            <ul>
                                <li> Fixed facebook / google login issues.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.5
                                <small>20th March 2018</small></h6>
                            <ul>
                                <li> Added new theme (default).</li>
                                <li> Fixed issues & high security vulnerability.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.4.3
                                <small>30th January 2018 (Important update!)</small></h6>
                            <ul>
                                <li> Fixed issues & high security vulnerability.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.4.2
                                <small>4th January 2018</small></h6>
                            <ul>
                                <li> Added Indian currency.</li>
                                <li> Added new API for movies, stories.</li>
                                <li> Fixed 7+ important reported bugs.</li>
                                <li> Script stability checkout.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.4.1
                                <small>22th December 2017</small></h6>
                            <ul>
                                <li> Added Cache-Control to Amazon hosted files.</li>
                                <li> Fixed 5+ important reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.4
                                <small>13th December 2017</small></h6>
                            <ul>
                                <li> Added the ability for users to send money to each other using their wallet balance. </li>
                                <li> Added Email messages notification for offline users. </li>
                                <li> Added the ability to import images from links in post system. </li>
                                <li> Added profile percentage system. (Fill your profile details for new users). </li>
                                <li> Added new pagination system with a search feature to admin panel (Users, Pages, Groups, Posts).</li>
                                <li> Added new ads placed in the ads system (Users can create ads on videos posts).</li>
                                <li> Added Iframe support for the forum Editor. </li>
                                <li> Added share to Matt Community button to blogs.</li>
                                <li> Added the ability for users to choose a default thumb when uploading a video in publisher box.</li>
                                <li> Added playtube video player integration.</li>
                                <li> Changed video player to mediaelement.js </li>
                                <li> Expired events will be deleted automatically.</li>
                                <li> Hid admin details in mass notification system and replaced it with site favicon/name.</li>
                                <li> Changed the blog system design.</li>
                                <li> Fixed 7+ reported bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.3.2
                                <small>15th November 2017</small></h6>
                            <ul>
                                <li> Added more regions to Amazon S3. </li>
                                <li> Added explore link to left sidebar. </li>
                                <li> Fixed 15+ reported bugs. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.3.1
                                <small>21th October 2017</small></h6>
                            <ul>
                                <li> Added custom currency for the ads system. </li>
                                <li> Added web push notifications. </li>
                                <li> Added custom CSS / JS code to admin panel. </li>
                                <li> Fixed 10+ reported bugs. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.3
                                <small>1st October 2017</small></h6>
                            <ul>
                                <li> Added new powerful admin panel. </li>
                                <li> Added push notification system for all site notifications. </li>
                                <li> Added the abiltiy to disable wonder/dislike buttons. </li>
                                <li> Added new API files, find friends, events, stories create groups pages and events. </li>
                                <li> Added support for Opera mini and UC browsers. </li>
                                <li> Fixed 15+ reported bugs. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.2
                                <small>4th September 2017</small></h6>
                            <ul>
                                <li> Added privacy option for users “Share my location with public?”. </li>
                                <li> Added friends stories to home page. </li>
                                <li> User now can view his own ads. </li>
                                <li> Added the option to upload images to blog system. </li>
                                <li> Added multi currency in classified. </li>
                                <li> Added video chat API for the windows application. </li>
                                <li> Added ads prices in craete ads page. </li>
                                <li> Improved the ads view design. </li>
                                <li> Improved admin panel, changed tables to datatable.js </li>
                                <li> User can't create ads if wallet is empty. </li>
                                <li> Fixed 40+ reported bugs / improvements. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5.1
                                <small>27th August 2017</small></h6>
                            <ul>
                                <li> Fixed all reported bugs. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.5
                                <small>24th August 2017</small></h6>
                            <ul>
                                <li> Added advertisement system. (Clicks, impressions) </li> 
                                <li> Added story system. (status, automatically gets removed after 24 hours).  </li> 
                                <li> Added new comment system for blogs and movies. </li> 
                                <li> Added group chat system. </li> 
                                <li> Added mass notification system in the admin panel. </li> 
                                <li> Added the ability to edit comment's replies. </li> 
                                <li> Added the ability to delete posts directly from home page (admins). </li> 
                                <li> Added the ability to delete any comment (admins). </li> 
                                <li> Added hide posts feature. </li> 
                                <li> Added 30+ more emojis. </li> 
                                <li> Added full verification form (ID, photo, description). </li> 
                                <li> Added new post sharing system. </li> 
                                <li> Added sitemap generator. </li> 
                                <li> Added registration invite system (Users can register just with invite link). </li> 
                                <li> Added new albums style (Collapsed). </li> 
                                <li> Added new admin panel sidebar (Collapsed). </li> 
                                <li> Added the ability to choose specific users in Mailing List. </li> 
                                <li> Added the ability to enable/disable ads system, story system. </li> 
                                <li> Added manage ads, stories (status) in the admin panel. </li> 
                                <li> Added "Who can see my friends" privacy option. </li> 
                                <li> Added multi date formats support. </li> 
                                <li> Added the ability to lose the verification if the username was changed. </li> 
                                <li> Added youtube/video link support for movies system. </li> 
                                <li> Added multi admins for groups and pages. </li> 
                                <li> Added gifs using "Giphy" API for messages/posts. </li> 
                                <li> Added API support for upcoming IOS application. </li> 
                                <li> Added Lightbox for images on messages, comments, and replies. </li> 
                                <li> Added page rate system, users can rate page from 0/5. </li> 
                                <li> Added report system for profiles, pages, and groups. </li> 
                                <li> Added new API for the new powerful windows desktop application. </li> 
                                <li> Added family members list (add a friend as a brother, father etc..) </li> 
                                <li> Added relationship assignment, e.g: Lisa is in a relationship with Zach </li> 
                                <li> Added find friends nearby (find friends near you within 100KM). </li> 
                                <li> Added alert feedback if file mime type/extension is not supported. </li> 
                                <li> Added alert if the file is larger than the max allowed size in publisher box, messages and chat. </li> 
                                <li> Upgraded Password hash system from MD5 to SHA1 </li> 
                                <li> Changed the trending system to be updated weekly. </li> 
                                <li> Updated font-awesome library. </li> 
                                <li> Updated emojis library. </li> 
                                <li> Fixed bugs on API. </li> 
                                <li> Fixed major bugs in the script. (+30) </li> 
                                <li> Improved load speed. </li> 
                                <li> Fixed 2 security issues. </li> 
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.5.2
                                <small>18th June 2017</small></h6>
                            <ul>
                                <li> Added audio recording to Post/Comment systems.  </li>
                                <li> Upgraded the API to the newest version for the new android messenger update.  </li>
                                <li> Fixed bugs in the script.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.5.1
                                <small>6th June 2017</small></h6>
                            <ul>
                                <li> Added movies system. </li>
                                <li> Added translate system for posts. </li>
                                <li> Added video views system. </li>
                                <li> Fixed twilio SMS bug. </li>
                                <li> Fixed bugs in the native app API. </li>
                                <li> Fixed few bugs in the script. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.5
                                <small>25th May 2017</small></h6>
                            <ul>
                                <li> Added forum system. </li>
                                <li> Added events system.  </li>
                                <li> Added "Login with Matt Community" API feature + applications + documentation.   </li>
                                <li> Added "load more" button to the advanced search page.   </li>
                                <li> Added "Share to Matt Community" button for third-party websites + documentation.    </li>
                                <li> Added custom chat colors for each conversation.   </li>
                                <li> Added push notifications support for Android messenger.   </li>
                                <li> Fixed video/audio call bugs.  </li>
                                <li> Fixed bugs in the native app API.   </li>
                                <li> Fixed few bugs in the script.  </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.4.5
                                <small>11th April 2017</small></h6>
                            <ul>
                                <li> Added blog system. </li>
                                <li> Final release for full API system (for native apps). </li>
                                <li> Fixed few bugs. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.4.4
                                <small>2nd March 2017</small></h6>
                            <ul>
                                <li> Added auto-updater system. </li>
                                <li> Added windows server rewrite URL support (web.config). </li>
                                <li> Fixed few bugs in the API. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.4.3
                                <small>23th February 2017</small></h6>
                            <ul>
                                <li> Improved the script theme.</li>
                                <li> Upgraded jQuery library. </li>
                                <li> Increased script speed. </li>
                                <li> Fixed few bugs in the API. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.4.2
                                <small>10th February 2017</small></h6>
                            <ul>
                                <li> Updated API for IOS messenger.</li>
                                <li> Fixed few bugs in the script. </li>
                                <li> Fixed few bugs in the API. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.4.1
                                <small>27th January 2017</small></h6>
                            <ul>
                                <li> Updated Hybridauth library (Facebook login bug). </li>
                                <li> Fixed more than +3 other bugs. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.4
                                <small>11th January 2017</small></h6>
                            <ul>
                                <li> Added "Read more" to product description. </li>
                                <li> Added custom currency option for classified. </li>
                                <li> Added custom mime types option to admin panel. </li>
                                <li> Updated PHPmailer library (Security bug).</li>
                                <li> Updated Hybridauth library (Google+ login bug). </li>
                                <li> Fixed "copyright" text in footer. </li>
                                <li> Fixed RTL design problems. </li>
                                <li> Fixed UTF-8 issues in hashtag system. </li>
                                <li> Fixed JavaScript code bugs in Apple products. </li>
                                <li> Fixed Android / Windows messengers API requests. </li>
                                <li> Optimized admin panel. </li>
                                <li> Fixed more than +5 other bugs. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.3
                                <small>8th December 2016</small></h6>
                            <ul>
                                <li> Added the ability to translate custom fields. </li>
                                <li> Added the ability to add/edit/remove languages from admin panel. </li>
                                <li> Added audio calls. </li>
                                <li> Added integration with the new <a href="https://codecanyon.net/item/Matt Community-android-messenger-mobile-application-for-Matt Community/19034167?s_rank=1">Matt Community Android Messenger</a>.</li>
                                <li> Added the ability to manage pro membership periods. </li>
                                <li> Added a button to manage and cancel expired pro users. </li>
                                <li> Added Twilio API for sending SMS messages. </li>
                                <li> Added android API for the upcoming native apps. </li>
                                <li> Added Alipay to Stipe. </li>
                                <li> Added hashtag post streaming. </li>
                                <li> Added YouTube field to page social link settings. </li>
                                <li> Added location field to classified system. </li>
                                <li> Improved database structure. </li>
                                <li> Improved SQL queries. </li>
                                <li> Improved script speed. </li>
                                <li> Design/Code optimization. </li>
                                <li> Fixed bugs in messages system. </li>
                                <li> Fixed few bugs. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.2
                                <small>10th October 2016</small></h6>
                           <ul>
                                <li> Added Amazon S3 integration. </li>
                                <li> Added the ability to delete full conversations. </li>
                                <li> Added the ability to delete recipient messages. </li>
                                <li> Added Nginx support. </li>
                                <li> Fixed an issue in login system. </li>
                                <li> Fixed an issue while deleting a page from admin panel. </li>
                                <li> Fixed few more bugs. </li>
                           </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4.1
                                <small>3rd October 2016</small></h6>
                            <ul>
                                <li> More than 10+ old and new bug fixes. </li>
                                <li> Design/Code optimization. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.4
                                <small>25th September 2016</small></h6>
                            <ul>
                                <li>Added new welcome page. </li>
                                <li>Added custom fields system. </li>
                                <li>Added classified system. </li>
                                <li>Added full affiliates system + payments. </li>
                                <li>Added poll system. </li>
                                <li>Added custom pages system. </li>
                                <li>Added more payment methods, (Credit card, Bitcoin, american express). </li>
                                <li>Added YouTube field to social links. </li>
                                <li>Added integration with the new <a href="https://codecanyon.net/item/Matt Community-desktop-a-windows-messenger-for-Matt Community/18029772">Windows Desktop Messenger</a>. </li>
                                <li>Added new posts updater system (Like twitter). </li>
                                <li>Added image on comments system. </li>
                                <li>Added full messaging API code for windows / Android / IOS. </li>
                                <li>Added CSRF protection for more forms / ajax requests. </li>
                                <li>Added terms link to registration page. </li>
                                <li>Added the option to enable/disable notification sound. </li>
                                <li>Added the option for user to filter posts by all or following. </li>
                                <li>Added more ad placements (between posts). </li>
                                <li>Added 'latest products' placement in sidebar. </li>
                                <li>Added longer user session time. </li>
                                <li>Added new design for messages system. </li>
                                <li>Added custom backgrounds for pages. </li>
                                <li>Replaced the URL scrape system with better one. </li>
                                <li>Re-coded style.css file to .scss for easy coding and outputting. </li>
                                <li>Speed/Design/Code optimization. </li>
                                <li>Fixed Hashtag issues. </li>
                                <li>Fixed birthday privacy issue. </li>
                                <li>Fixed image rotation issue. </li>
                                <li>Fixed image cropping issues. </li>
                                <li>Fixed session hijacking security.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.3.4
                                <small>27th June 2016</small></h6>
                            <ul>
                                <li> Fixed all reported bug. </li>
                                <li> Increased the script speed by 50%. </li>
                                <li> Design/Code optimization. </li>
                                <li> Upgraded the image optimization system to next level. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.3.3
                                <small>19th June 2016</small></h6>
                            <ul>
                                <li> Added video call/chat system for all devices. </li>
                                <li> Added the option to view all posts or following posts. </li>
                                <li> Added the option to enable/disable "developers" page. </li>
                                <li> Added the option to enable/disable user registration. </li>
                                <li> Added "maintenance_mode" to shut down the whole site. </li>
                                <li> Added the option to send mailing list to "active, inactive, all" users. </li>
                                <li> Added "disabled button" background color to admin panel. </li>
                                <li> Added dropdown menu for messages button in header. </li>
                                <li> Added gender field for Facebook social login. </li>
                                <li> Added max posts/pages boosts allowed for per pro user to admin panel. </li>
                                <li> Added "eapi link" for sending SMS. </li>
                                <li> Added multi chat tabs (max 3 tabs). </li>
                                <li> Added the option to change favicon from admin panel. </li>
                                <li> Added CSRF protection for few more forms. </li>
                                <li> Upgraded chat system + messages. </li>
                                <li> Updated API to v1.3.1 </li>
                                <li> Optimized admin panel layout. </li>
                                <li> Fixed few bugs. </li>
                                <li> Speed/Design/Code optimization. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.3.2
                                <small>17th May 2016</small></h6>
                            <ul>
                                <li> Added the ability enable/disable games, pages, groups. </li>
                                <li> Added full backup system, (backup your files, database, uploads easily with one click via admin panel). </li>
                                <li> Added more currency types for payments, (RUB, PLN, ILS, BRL). </li>
                                <li> Added pull to refresh to android application. </li>
                                <li> Added test log for PayPal configuration. </li>
                                <li> Speeded up loading time. </li>
                                <li> Fixed redirection issue, (www or without www). </li>
                                <li> Fixed default language on sign up. </li>
                                <li> Fixed common bugs. </li>
                                <li> Script optimization. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.3.1
                                <small>24th April 2016</small></h6>
                            <ul>
                                <li> Added more currency types for payments.</li>
                                <li> Added the ability for groups admin to delete users posts.</li>
                                <li> Added Portuguese language.</li>
                                <li> Added 2 new design types to admin panel for header, (header input text, buttons text shadow).</li>
                                <li> Added send button to comment field. (On mobile) </li>
                                <li> Fixed common bugs.</li>
                                <li> Fixed security bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.3
                                <small>21th April 2016</small></h6>
                            <ul>
                                <li> Added SMS verification system (verify user by phone number).</li>
                                <li> Added premium members (Star - Hot - Utlima - Vip) with PayPal / credit card integration.</li>
                                <li> Added Android, IOS, and Windows Phone apps (web-view).</li>
                                <li> Added cover re-position feature.</li>
                                <li> Added birthday events on home page.</li>
                                <li> Added the ability to boost posts & pages with monthly payments.</li>
                                <li> Added post limit p/ hour for every user.</li>
                                <li> Added registration limit p/ hour for every IP.</li>
                                <li> Added custom CSS file for every user (user can completely re-design his own profile).</li>
                                <li> Added Video.JS/Audio.JS for video & audio players.</li>
                                <li> Added new speed for all action, (follow, add friend, chat, like, dislike, wonder, join etc ..).</li>
                                <li> Added desktop notifications for Google Chrome / FireFox.</li>
                                <li> Added the ability to upload .mov, .flv, .mpeg Videos.</li>
                                <li> Added CSRF protection for common forms.</li>
                                <li> Added user ranks, admin - moderator - user.</li>
                                <li> Added send button to messages.</li>
                                <li> Added top featured users bar (applying by paying).</li>
                                <li> Added online users list to admin panel.</li>
                                <li> Added invite system.</li>
                                <li> Added og-Meta tags for social sharing.</li>
                                <li> Added new loading system (loading content without refreshing the page) & bandwidth saver system.</li>
                                <li> Added new E-mail notification system.</li>
                                <li> Added block system.</li>
                                <li> Added new sources for games importing.</li>
                                <li> Optimized layout.</li>
                                <li> Speeded up SMTP.</li>
                                <li> Replaced cache system.</li>
                                <li> Removed /welcome from welcome page URL.</li>
                                <li> Updated API to v1.3.</li>
                                <li> Script & code optimization.</li>
                                <li> SEO optimization.</li>
                                <li> Improved chat system usage of resources.</li>
                                <li> Increased site security (XSS, CSRF, SQL, Spams).</li>
                                <li> Fixed default country (USA).</li>
                                <li> Fixed common bugs.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.2.3
                                <small>26th February 2016</small></h6>
                            <ul>
                                <li> Added SMTP server.<br>
                                <li> Added Login with username or email.</li>
                                <li> Added Build Version to admin panel.</li>
                                <li> Fixed major bugs.</li>
                                <li> Improved Security.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.2.2
                                <small>29th January 2016</small></h6>
                            <ul>
                                <li> Added auto suggestion for mentions in publisher box, comments, replies.</li>
                                <li> Added Start up pages (Add photo, Fill some information, Follow users).</li>
                                <li> Added terms pages to admin panel. (Admin can now edit terms pages from admin panel).</li>
                                <li> Added video, audio upload setting to admin panel.</li>
                                <li> Added welcome background image changer to admin panel.</li>
                                <li> Added site design colors to email notification.</li>
                                <li> Added user profile privacy for non-logged users.</li>
                                <li> Added smiles button to comment, send message boxs.</li>
                                <li> Added installer for easy installation.</li>
                                <li> Fixed Bugs from your feedback.</li>
                                <li> Script Optimization.</li>
                                <li> Improved Speed.</li>
                                <li> Improved Security.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.2.1
                                <small>12th January 2016</small></h6>
                            <ul>
                                <li> Added words wonder, dislike, like to the post action buttons.</li>
                                <li> Added the ability to just like or dislike. (can't do it both).</li>
                                <li> Re added emotions to post publisher box. </li>
                                <li> Optimized chat requests.</li>
                                <li> Fixed bugs from your feedback.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.2
                                <small>10th January 2016</small></h6>
                            <ul>
                                <li> Added group system</li>
                                <li> Added game system</li>
                                <li> Added dislike button (wonder or dislike)</li>
                                <li> Added new lightbox</li>
                                <li> Added login via Instagram</li>
                                <li> Added verification request system</li>
                                <li> Added photo album system</li>
                                <li> Added multi photos upload</li>
                                <li> Added autoload system for posts</li>
                                <li> Added new search system</li>
                                <li> Added recent searches</li>
                                <li> Added page invitation system</li>
                                <li> Added group invitation system</li>
                                <li> Added ban ip system</li>
                                <li> Added feelings/travailing/watching/playing/listening post status</li>
                                <li> Added call to action system for pages</li>
                                <li> Added online user counter on admin & home page</li>
                                <li> Added location autocomplete for user/page setting</li>
                                <li> Added design system (Customize your own website style & colors on very easy way from admin panel)</li>
                                <li> Added recent searches</li>
                                <li> Added notification popup</li>
                                <li> Added profile visit privacy</li>
                                <li> Added last seen privacy</li>
                                <li> Added profile birthday privacy</li>
                                <li> Added auto detector for Youtube, Dailymotion, Vine, Vimeo, Facebook videos & soundcloud links.</li>
                                <li> Added https support</li>
                                <li> Added comment replies system</li>
                                <li> Added comment auto detector</li>
                                <li> Added education to user profile information</li>
                                <li> Added the ability to like/dislike/wonder/comment on user's profile picture & cover image</li>
                                <li> Added email notification setting</li>
                                <li> Added site statistics charts in admin panel</li>
                                <li> Added ip address field to manage users page</li>
                                <li> Added new language (Italian)</li>
                                <li> Removed "@" from user profile URL</li>
                                <li> Removed "p/" from page URL</li>
                                <li> Removed "/home" from home page URL</li>
                                <li> Changed the entire admin panel layout</li>
                                <li> Changed the entire user/page/group setting layout</li>
                                <li> Improved user popover</li>
                                <li> Improved layout</li>
                                <li> Improved layout on smartphones</li>
                                <li> Improved chat system</li>
                                <li> Improved site security</li>
                                <li> Improved link preview</li>
                                <li> Improved cache system to a higher level</li>
                                <li> Updated API version to v1.1</li>
                                <li> Script optimization</li>
                                <li> Bug fixes </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.1
                                <small>8th December 2015</small></h6>
                            <ul>
                                <li> Added Page System.</li>
                                <li> Added Link Preview.</li>
                                <li> Added User Typing System & Message "Seen" System.</li>
                                <li> Added Profile Custom fields (Work, Company, Relationship, Location .. etc).</li>
                                <li> Added Profile Google Map location.</li>
                                <li> Added Profile Background image. (user can choose his own background image).</li>
                                <li> Added Facebook, Vimeo, Dailymotion videos.</li>
                                <li> Added User Details On Hovering on user link.</li>
                                <li> Added Censored Words System.</li>
                                <li> Added 4 New Languages (Dutch, German, Spanish, French).</li>
                                <li> Added Search Posts System.</li>
                                <li> Added HTML Support For Announcements.</li>
                                <li> Changed Welcome Page Style.</li>
                                <li> Changed Sidebar Style.</li>
                                <li> Improved Layout & Styles.</li>
                                <li> Improved Layout On Smartphones.</li>
                                <li> Improved Admin Panel Layout.</li>
                                <li> Added More features for Sending emails to all users.</li>
                                <li> Script Optimization.</li>
                                <li> Fixed Bugs.</li>
                                <li> Improved Security.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">v1.0</h6>
                            Version 1.0 released on 26 November 2015.
                        </div>
                    </div>
                </div>
            </div>
        </div>
		</div>
	</div>
	
	<!--Pricing-->
	

<div id="pricing" class="section bg_light py_lg co_stats pricing-section">
    <div class="container-fluid">
        <div class="text-center">
            <h1 class="display_7 pure_white">Choose your plan</h1>
            <div class="price-btn"> 
                <a href="javascript:void(0);" id="monthly" class="price-btn-bg btn btn-xl btn-outline-light my-2 mx-2">Monthly Fee</a>
                <a href="javascript:void(0);" id="one-time" class="btn btn-xl btn-outline-light my-2 mx-2">One Time Fee</a>
            </div>
        </div>


        <div id="monthly-section">
             <div class="row text-center mb-5">
                 <div class="col-lg-12 col-md-12">
                      <div class="price-btn"> 
                        <p class="white_text mt-3 mb-0">Host and Manage your Website on our Servers for a Monthly Fee!</p>
                        <p class="white_text ">Your Website will Automatically Install and Set Up in Seconds!</p>
                        
                      </div>
                  </div>
            </div>

              <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>MooSocial License</h4>
                                <h5 class="card-title mb-0">$99</h5>
                                <h3 class="mb-0"><b>A Month</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>3o Day fee support</li>
                                    <li>Include all Core Features and Core Plugin: Blog, Photo, Video, Topics, Groups, Events</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>You can buy mooSocial license now then get the apps in combo packages later here</li>
                                </ul>
                            </div> 
                              <a href="#" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label>
                                        <input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span>
                                    </label>
                                </div>
                                  <div class="bottom-link">  
                                    <a href="#" class="see-included">
                                        Installation Service
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Pro</h4>
                                <h5 class="card-title mb-0">$298</h5>
                                <h3 class="mb-0"><b>A Month</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>One mooSocial License ($99)</li>
                                    <select class="form-control">
                                        <option value="a">Android Licence ($199)</option>
                                        <option value="i">IOS Licence ($199)</option>
                                    </select>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li>60-days free support</li>
                                </ul>
                            </div> 
                              <a href="#" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label>
                                        <input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span>
                                    </label>
                                </div>
                                 <div class="bottom-link"> 
                                    <a href="#" class="see-included">
                                        Installation Service
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Deluxe</h4>
                                <h5 class="card-title mb-0">$398</h5>
                                <h3 class="mb-0"><b>A Month</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>Free mooSocial Licence ($99)</li>
                                    <li>Android and IOS Licence ($398)</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li>60-days free support</li>
                                </ul>
                            </div> 
                              <a href="#" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label>
                                        <input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span>
                                    </label>
                                </div>
                                 <div class="bottom-link"> 
                                    <a href="#" class="see-included">
                                        Installation Service
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Ultimate</h4>
                                <h5 class="card-title mb-0">$1669</h5>
                                <h3 class="mb-0"><b>A Month</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>Free mooSocial Licence ($99)</li>
                                    <li>Android and IOS Licence ($398)</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li class="bottom-link" data-toggle="collapse" data-target="#more">
                                        <a href="javascript:Void(0);">Read More</a>
                                    </li>
                                    <div id="more" class="collapse">
                                        <li>All Paid Plugins + 1 Theme</li>
                                        <li>Free Installation Service ($99)</li>
                                        <li>60-days free support</li>
                                        <select class="form-control">
                                            <option value="">mooSpace Theme</option>
                                            <option value="">mooOrigin Landing Page</option>
                                            <option value="">The Mommy &amp; Baby Theme</option>
                                            <option value="">mooPinterest Theme</option>
                                            <option value="">mooTimline Theme</option>
                                            <option value="">mooTube Background Theme</option>
                                            <option value="">mooX Job Theme</option>
                                            <option value="">mooX Theme</option>
                                            <option value="">mooUniversity Theme</option>
                                            <option value="">mooCooking Theme</option>
                                            <option value="">mooSocio Theme</option>
                                            <option value="">mooSport / Fancenter Theme</option>
                                            <option value="">mooInsider Theme</option>
                                            <option value="">DatingIsArt Theme</option>
                                            <option value="">RallyUP Theme</option>
                                            <option value="">Petlover Theme</option>
                                            <option value="">mooPlus (Google Plus Inspired Theme)</option>
                                            <option selected="selected" value="5929">mooBook (Facebook Inspired Theme)</option>
                                        </select>
                                    </div>
                                </ul>
                            </div>
                            <a href="#" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                  <div class="bottom-link"> 
                                    <a href="#" class="see-included"> View Demo</a>
                                </div>
                                  <div class="bottom-link"> 
                                    <a href="#" class="see-included">Installation Service </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div id="one-time-section">
            <div class="row text-center mb-5">
                 <div class="col-lg-12 col-md-12">
                      <div class="price-btn"> 
                       <p class="white_text mt-3 mb-0">Host, Manage, setup, and install your website on your own server for a one time fee</p>
                      </div>
                  </div>
            </div>

             <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>MooSocial License</h4>
                                <h5 class="card-title mb-0">$199</h5>
                                <h3 class="mb-0"><b>One-time-fee</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>3o Day fee support</li>
                                    <li>Include all Core Features and Core Plugin: Blog, Photo, Video, Topics, Groups, Events</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>You can buy mooSocial license now then get the apps in combo packages later here</li>
                                </ul>
                            </div> 
                            <a href="#" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label><input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span></label>
                                </div>
                                <div class="bottom-link"> 
                                    <a href="#" class="see-included">Installation Service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Pro</h4>
                                <h5 class="card-title mb-0">$308</h5>
                                <h3 class="mb-0"><b>One-time-fee</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>One mooSocial License ($99)</li>
                                    <select class="form-control">
                                        <option value="a">Android Licence ($199)</option>
                                        <option value="i">IOS Licence ($199)</option>
                                    </select>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li>60-days free support</li>
                                </ul>
                            </div>
                              <a href="#" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label>
                                        <input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span>
                                    </label>
                                </div>
                               <div class="bottom-link"> 
                                    <a href="#" class="see-included">
                                        Installation Service
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Deluxe</h4>
                                <h5 class="card-title mb-0">$452</h5>
                                <h3 class="mb-0"><b>One-time-fee</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>Free mooSocial Licence ($99)</li>
                                    <li>Android and IOS Licence ($398)</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li>60-days free support</li>
                                </ul>
                            </div> 
                              <a href="#" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label>
                                        <input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span>
                                    </label>
                                </div>
                                <div class="bottom-link"> 
                                    <a href="#" class="see-included">Installation Service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Ultimate</h4>
                                <h5 class="card-title mb-0">$2569</h5>
                                <h3 class="mb-0"><b>One-time-fee</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>Free mooSocial Licence ($99)</li>
                                    <li>Android and IOS Licence ($398)</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li class="bottom-link" data-toggle="collapse" data-target="#more">
                                        <a href="javascript:Void(0);">Read More</a>
                                    </li>
                                    <div id="more" class="collapse">
                                        <li>All Paid Plugins + 1 Theme</li>
                                        <li>Free Installation Service ($99)</li>
                                        <li>60-days free support</li>
                                        <select class="form-control">
                                            <option value="">mooSpace Theme</option>
                                            <option value="">mooOrigin Landing Page</option>
                                            <option value="">The Mommy &amp; Baby Theme</option>
                                            <option value="">mooPinterest Theme</option>
                                            <option value="">mooTimline Theme</option>
                                            <option value="">mooTube Background Theme</option>
                                            <option value="">mooX Job Theme</option>
                                            <option value="">mooX Theme</option>
                                            <option value="">mooUniversity Theme</option>
                                            <option value="">mooCooking Theme</option>
                                            <option value="">mooSocio Theme</option>
                                            <option value="">mooSport / Fancenter Theme</option>
                                            <option value="">mooInsider Theme</option>
                                            <option value="">DatingIsArt Theme</option>
                                            <option value="">RallyUP Theme</option>
                                            <option value="">Petlover Theme</option>
                                            <option value="">mooPlus (Google Plus Inspired Theme)</option>
                                            <option selected="selected" value="">mooBook (Facebook Inspired Theme)</option>
                                        </select>
                                    </div>
                                </ul>
                            </div> 
                            <a href="#" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="bottom-link"> 
                                    <a href="#" class="see-included"> View Demo</a>
                                </div>
                               <div class="bottom-link"> 
                                    <a href="#" class="see-included">Installation Service </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

     </div>
 </div>
</div>
	
	<!--Newsletter-->
	<div class="section co_subscribe">
        <div class="container">
			<div class="section_title text-center">
                <h1 class="display_7 vhid wow fadeInUp">Subscribe to Newsletter</h1>
				<p class="vhid wow fadeInUp">We'll never Spam your Inbox!</p>
            </div>
            <div class="row">
				<div class="col-lg-3"></div>
				<form class="col col-md-12 col-lg-6" method="post" action="https://www.matt community.com/subscribe.php">
					<div class="col-sm-8 pull-left">
						<input class="form-control" name="email" type="email" placeholder="Your Email" required="">
					</div>
					<div class="col-sm-4 pull-left">
						<button type="submit" class="btn btn-xl btn-block btn-primary">Subscribe</button>
					</div>
				</form>
				<div class="col-lg-3"></div>
            </div>
        </div>
    </div>

	<!--Footer-->
<div class="section bg_dark mt-4" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <img src="images/logo/logo.png" class="logo-dark" alt="Start.ly Logo" />
                    <p class="mt-3 ml-1 white_text">Lorem ipsum dolor sit amet, ut ius audiam denique  tractatos, pro cu dicat quidam neglegentur. Vel mazim aliquid.</p>
                   
                </div>
                <div class="col-sm-3">
					<h6 class="display_6">More</h6>
                    <ul class="list-unstyled footer-links ml-1">
                        <li><a href="#">Customization</a></li>
                        <li><a href="#">Documentation</a></li>
                    </ul>
                </div>
             
                <div class="col-sm-3">
					<h6 class="display_6">Follow Us</h6>
                    <ul class="list-unstyled footer-links ml-1">
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Twitter</a></li>
                    </ul>
                </div>

                 <div class="col-sm-3">
                    <h6 class="display_6">Our Place</h6>
                    <ul class="list-unstyled footer-links ml-1">
                        <li><a href="javascript:void(0);"><i class="pe-7s-map-marker"></i> Lorem Ipsum? dolor sit</a></li>
                        <li><a href="#"><i class="pe-7s-mail"></i> abc@example.com</a></li>
                        <li><a href="#"><i class="pe-7s-phone"></i> +91 9876543210</a></li>
                    </ul>
                </div>

            </div>
            <div class=" text-center white_text mt-4"> Copyright © Matt community. All rights reserved, Made with Love <span class="footer-hart"><i class="fa fa-heart"></i></span></div> 
        </div>
    </div>

	<a href="#home" class="co_top">
        <i class="pe-2x pe-7s-angle-up font-weight-bold"></i>
    </a>

    <script src="js/js-library/jquery-3.2.1.min.js"></script>
    <script src="js/js-library/bootstrap.min.js"></script>
	<script src="js/js-library/twinlight.js"></script>
    <script src="js/script.js"></script>
     <script src="js/common.js"></script>

  </body>


<!-- Mirrored from questwalktech.com/matt-subscription/change-log.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jun 2022 10:20:25 GMT -->
</html>
