<?php require './Config.php'; ?>
<!--header-->
<?php require './header.php'; ?>

<?php 
    error_reporting(0);
    include("Database.php");

    //Select all plugins for user section

    $result = mysqli_query($conn, "SELECT * from crm_headings");
    
    $options = array();
    $headings = array();
    //Getting options 
    while($heading = mysqli_fetch_assoc($result)){
        
        $data = mysqli_query($conn, "SELECT * from crm_options where heading_id=".$heading['heading_id']);
        
        $temp = array();
        while($a = mysqli_fetch_assoc($data)){
            $temp[] = $a;
        }
        $options[$heading['heading_id']] = $temp;
        $headings[] = $heading;
    }

    //$result = (mysqli_query($conn, "SELECT * from crm_items Order By rate DESC"));    
    $result = (mysqli_query($conn, "SELECT * from crm_items "));    
    // Fetch the data and store it in an array
    $items = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $items[] = $row;
    }
     // echo"<pre>";print_r($items);die;


    // CODE FOR DISPALY THE ANNOUNCEMENT
    $result = (mysqli_query($conn, "SELECT `setting_value` from `crm_settings` WHERE `setting_name`='timezone'"));
    $row = mysqli_fetch_assoc($result);
    $timezoneSetting = $row["setting_value"];
    
    $d = DateTime::createFromFormat("Y-m-d H:i:s", date("Y-m-d H:i:s"));
    $d->setTimeZone(new DateTimeZone("UTC"));
    $d = $d->format("Y-m-d H:i:s");

    $timeZone = new DateTimeZone($timezoneSetting);
    $dateTime = new DateTime("now", $timeZone);
    $timeZone = $timeZone->getOffset($dateTime);

    $now = date("Y-m-d H:i:s", strtotime($d) + $timeZone); 
    
    $announcements = (mysqli_query($conn, "SELECT * from crm_announcements WHERE start_date<='$now' AND end_date>='$now' AND deleted = 0"));
    $annouce = array();
    while ($row = mysqli_fetch_assoc($announcements)) {
        $annouce[] = $row;
    }
    // CODE FOR DISPALY THE ANNOUNCEMENT

 ?>



<!--header-->
<!-- <!DOCTYPE html>
<html lang="en">



<head>
    <title>Matt Community</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no, minimal-ui" />
    <link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="images/logo/icon.png" />
    <link rel="stylesheet" href="css/css-library/bootstrap.min.css">
    <link rel="stylesheet" href="css/css-library/icon-font.css">
    <link rel="stylesheet" href="css/css-library/welcome.css">
    <link rel="stylesheet" href="css/style7e0c.css?v=0.1">
</head>

<body> -->
<!-- <div id="home"> -->
<!-- 
        <section class="top-header">
            <div class="container-fluid">
                <div class="row">

                     <div class="col-md-6">
                        <div class="left-menu">
                            <ul class="text-left mb-0">
                                <li> 
                                    <a class="nav-link" href="emailto:abc@example.com"><i class="fa fa-envelope-o"></i> abc@example.com</a>
                                </li>
                                <li> 
                                    <a class="nav-link" href="tel:+99 9876543210"><i class="fa fa-phone"></i> +99 9876543210</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-6 col-12">
                        <div class="left-menu">
                            <ul class="text-right mb-0">
                                <li> 
                                    <a class="nav-link" href="https://www.questwalktech.com/matt-subscription/store-admin/index.php/signin">Login</a>
                                </li>
                                <li> 
                                    <a class="nav-link" href="https://www.questwalktech.com/matt-subscription/store-admin/index.php/signup">Register</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
<!-- 
        <nav id="navbar" class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index-2.php">
                    <img src="images/logo/logo.png" height="" width="180" alt="Matt Community">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#site-nav" aria-controls="site-nav" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="site-nav">
                    <ul class="navbar-nav text-sm-left ml-auto">
                        <li class="nav-item"> 
                            <a class="nav-link" href="index-2.php">Home</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item dropdown"> 
                            <a class="nav-link" href="#" data-toggle="dropdown">Features 
                                <span class="pe-2x pe-7s-angle-down"></span>  
                            </a>
                            <div class="dropdown-menu"> 
                                <a class="dropdown-item" href="comparison-table.php">Features Plan Comparison</a> -->
                                <!-- <a class="dropdown-item" href="#">Earn More Money</a>
                                <a class="dropdown-item" href="#">Instant Messaging</a>
                                <a class="dropdown-item" href="#">All payment methods are supported!</a>
                                <a class="dropdown-item" href="#">Powerful Live Streaming</a> -->
          <!--                   </div>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="pricing.php">Pricing</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="#">Plugins</a>
                        </li>
                        <li class="nav-item"> 
                            <a class="nav-link" href="contact.php">FAQ</a>
                        </li>
                        <li class="nav-item dropdown"> 
                            <a class="nav-link" href="#" data-toggle="dropdown">More 
                                <span class="pe-2x pe-7s-angle-down"></span>  
                            </a>
                            <div class="dropdown-menu"> 
                                <a class="dropdown-item" href="contact.php">Customization</a>
                                <a class="dropdown-item" href="contact.php">Documentation</a>
                                <a class="dropdown-item" href="contact.php">Change Log</a>
                            </div>
                        </li>
                       <li class="nav-item">
                           <a href="#" class="btn align-middle btn-primary my-2 my-lg-0">Demo</a>
                        </li>
                         <a href="pricing.php" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div> -->

<div class="py-1">
    <div class="container">
        <div class="text-center">
            <h1 class="mb-0">Feature Comparison Chart</h1>
        </div>
    </div>
</div>




<div id="comparison-table" class="section bg_light py_lg co_stats pricing-section">
    <div class="container-fluid">
        <div class="text-center">
            <h1 class="display_7 pure_white">Choose your plan</h1>
            <div class="price-btn"> 
                <a href="javascript:void(0);" id="monthly" class="price-btn-bg btn btn-xl btn-outline-light my-2 mx-2">Monthly Fee</a>
                <a href="javascript:void(0);" id="one-time" class="btn btn-xl btn-outline-light my-2 mx-2">One Time Fee</a>
            </div>
        </div>


        <div id="monthly-section">
             <div class="row text-center mb-5">
                 <div class="col-lg-12 col-md-12">
                      <div class="price-btn"> 
                        <p class="white_text mt-3 mb-0">Host and Manage your Website on our Servers for a Monthly Fee!</p>
                        <p class="white_text ">Your Website will Automatically Install and Set Up in Seconds!</p>
                        
                      </div>
                  </div>
            </div>


                    <div class="comparison-table-section ">
                        <div class="table-responsive">







                            <table class="table table-striped">
                        <thead>
                            <tr>
                                <th colspan="1" class="first-price-bg"></th>
                                <?php foreach( $items as $item){ 
                                    if($item['id'] != 6){
                                ?>
                                <th><?php echo $item['title'] ?>
                                    <br>$<?php echo number_format($item['rate'], 0, ".", ",") ?><br>
                                    <span class="span-month">A Month</span>
                                </th>
                                <?php }} ?>
                               <!--  <th>Pro
                                    <br>$298<br>
                                    <span class="span-month">A Month</span>
                                </th>
                                <th>Deluxe
                                    <br>$398<br>
                                    <span class="span-month">A Month</span>
                                </th>
                                <th>Ultimate
                                    <br>$1609<br>
                                    <span class="span-month">A Month</span>
                                </th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($headings as $heading) { ?>
                                <tr class="heading-table">
                                    <td><?php echo $heading['title']; ?></td>
                                    <?php if($heading['heading_id'] == 1){ ?>
                                        <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/1" class="btn align-middle btn-primary my-2 my-lg-0 table-subscribe-button"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a></td>
                                        <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/2" class="btn align-middle btn-primary my-2 my-lg-0 table-subscribe-button"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a></td>
                                        <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/3" class="btn align-middle btn-primary my-2 my-lg-0 table-subscribe-button"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a></td>
                                        <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/4" class="btn align-middle btn-primary my-2 my-lg-0 table-subscribe-button"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a></td>
                                     <?php }else{ ?>
                                        <td><i class="fa fa-close"></i></td>
                                        <td><i class="fa fa-close"></i></td>
                                        <td><i class="fa fa-close"></i></td>
                                        <td><i class="fa fa-close"></i></td>
                                     <?php } ?>
                                </tr>

                                <?php foreach( $options[$heading['heading_id']] as $option){ ?>
                                     <tr>
                                        <td><?php echo $option['title'] ?></td>
                                        <td><i class="fa fa-<?php echo ($option['plan_1']==1?'check':'close') ?>"></i>
                                        </td>
                                        <td><i class="fa fa-<?php echo ($option['plan_2']==1?'check':'close') ?>"></i>
                                        </td>
                                        <td><i class="fa fa-<?php echo ($option['plan_3']==1?'check':'close') ?>"></i>
                                        </td>
                                        <td><i class="fa fa-<?php echo ($option['plan_4']==1?'check':'close') ?>"></i>
                                        </td>
                                    </tr>
                                 <?php } ?>   
                            <?php } ?>
                           
                        </tbody>

                        <tfoot>

                        </tfoot>

                    </table>








                            <?php if (0): ?>

                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th colspan="1"></th>
                                        <th>License
                                            <br>$99<br>
                                            <span class="span-month">A Month</span>
                                        </th>
                                        <th>Pro
                                            <br>$298<br>
                                              <span class="span-month">A Month</span>
                                        </th>
                                        <th>Deluxe
                                            <br>$398<br>
                                              <span class="span-month">A Month</span>
                                        </th>
                                        <th>Ultimate
                                            <br>$1609<br>
                                              <span class="span-month">A Month</span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="heading-table">
                                        <td>Our guarantee</td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/1" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                       <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/2" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/3" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/4" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>30 day support</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>60 day support</td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>All Paid Plugins + 1 Theme</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Free Installation Services ($99)</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>One Year free updates</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>One time payment</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Instant download</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Source code access</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr class="heading-table">
                                        <td>Code Features</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>Activity Feeds</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>User Profile</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                     <tr>
                                        <td>Frinds</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                     <tr>
                                        <td>User Roles</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                     <tr>
                                        <td>Layout Editer</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>

                                    <tr class="heading-table">
                                        <td>Localization</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>Multilingual</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Right-to-Left</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>3rd Party Translations</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr class="heading-table">
                                        <td>Apps</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>REST API Library</td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>IOS App or Android App License</td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>IOS App and Android App License</td>
                                        <td></td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                </tbody>

                                   <tfoot>
                                    <tr>
                                        <th colspan="1"></th>
                                        <th>License
                                            <br>$99<br>
                                            <span class="span-month">A Month</span>
                                        </th>
                                        <th>Pro
                                            <br>$298<br>
                                              <span class="span-month">A Month</span>
                                        </th>
                                        <th>Deluxe
                                            <br>$398<br>
                                              <span class="span-month">A Month</span>
                                        </th>
                                        <th>Ultimate
                                            <br>$1609<br>
                                              <span class="span-month">A Month</span>
                                        </th>
                                    </tr>

                                     <tr class="heading-table">
                                        <td></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/1" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                       <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/2" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/3" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/4" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                    </tr>
                                </tfoot>

                            </table>




                            <?php endif ?>


                        </div>
                    </div>
               </div>


        <div id="one-time-section">
            <div class="row text-center mb-5">
                 <div class="col-lg-12 col-md-12">
                      <div class="price-btn"> 
                       <p class="white_text mt-3 mb-0">Host, Manage, setup, and install your website on your own server for a one time fee</p>
                      </div>
                  </div>
            </div>


                    <div class="comparison-table-section">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th colspan="1"></th>
                                        <th>License
                                            <br>$99<br>
                                            <span class="span-month">One Time Fee</span>
                                        </th>
                                        <th>Pro
                                            <br>$298<br>
                                              <span class="span-month">One Time Fee</span>
                                        </th>
                                        <th>Deluxe
                                            <br>$398<br>
                                              <span class="span-month">One Time Fee</span>
                                        </th>
                                        <th>Ultimate
                                            <br>$1609<br>
                                              <span class="span-month">One Time Fee</span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="heading-table">
                                        <td>Our guarantee</td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/1" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                       <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/2" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/3" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/4" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>30 day support</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>60 day support</td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>All Paid Plugins + 1 Theme</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Free Installation Services ($99)</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>One Year free updates</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>One time payment</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Instant download</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Source code access</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr class="heading-table">
                                        <td>Code Features</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>Activity Feeds</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>User Profile</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                     <tr>
                                        <td>Frinds</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                     <tr>
                                        <td>User Roles</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                     <tr>
                                        <td>Layout Editer</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>

                                    <tr class="heading-table">
                                        <td>Localization</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>

                                    <tr>
                                        <td>Multilingual</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Right-to-Left</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>3rd Party Translations</td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr class="heading-table">
                                        <td>Apps</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td>REST API Library</td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>IOS App or Android App License</td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>IOS App and Android App License</td>
                                        <td></td>
                                        <td></td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                        <td><i class="fa fa-check"></i>
                                        </td>
                                    </tr>
                                </tbody>

                                   <tfoot>
                                    <tr>
                                        <th colspan="1"></th>
                                        <th>License
                                            <br>$99<br>
                                            <span class="span-month">One Time Fee</span>
                                        </th>
                                        <th>Pro
                                            <br>$298<br>
                                              <span class="span-month">One Time Fee</span>
                                        </th>
                                        <th>Deluxe
                                            <br>$398<br>
                                              <span class="span-month">One Time Fee</span>
                                        </th>
                                        <th>Ultimate
                                            <br>$1609<br>
                                              <span class="span-month">One Time Fee</span>
                                        </th>
                                    </tr>

                                        <tr class="heading-table">
                                        <td></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/1" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                       <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/2" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/3" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                        <td class="text-center"><a href="https://questwalktech.com/matt-subscription/store-admin/index.php/items/pricing_add_to_cart/4" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                    </tr>
                                </tfoot>

                            </table>
                        </div>
                    </div>

                </div>

                
           
            </div>
        </div>







<!--Footer-->
<!-- <div class="section bg_dark mt-4" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <img src="images/logo/logo.png" class="logo-dark" alt="Start.ly Logo" />
                    <p class="mt-3 ml-1 white_text">Lorem ipsum dolor sit amet, ut ius audiam denique  tractatos, pro cu dicat quidam neglegentur. Vel mazim aliquid.</p>
                   
                </div>
                <div class="col-sm-3">
					<h6 class="display_6">More</h6>
                    <ul class="list-unstyled footer-links ml-1">
                        <li><a href="#">Customization</a></li>
                        <li><a href="#">Documentation</a></li>
                    </ul>
                </div>
             
                <div class="col-sm-3">
					<h6 class="display_6">Follow Us</h6>
                    <ul class="list-unstyled footer-links ml-1">
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Twitter</a></li>
                    </ul>
                </div>

                 <div class="col-sm-3">
                    <h6 class="display_6">Our Place</h6>
                    <ul class="list-unstyled footer-links ml-1">
                        <li><a href="javascript:void(0);"><i class="pe-7s-map-marker"></i> Lorem Ipsum? dolor sit</a></li>
                        <li><a href="#"><i class="pe-7s-mail"></i> abc@example.com</a></li>
                        <li><a href="#"><i class="pe-7s-phone"></i> +91 9876543210</a></li>
                    </ul>
                </div>

            </div>
            <div class=" text-center white_text mt-4"> Copyright � Matt community. All rights reserved, Made with Love <span class="footer-hart"><i class="fa fa-heart"></i></span></div> 
        </div>
    </div>

	<a href="#home" class="co_top">
        <i class="pe-2x pe-7s-angle-up font-weight-bold"></i>
    </a>

    <script src="js/js-library/jquery-3.2.1.min.js"></script>
    <script src="js/js-library/bootstrap.min.js"></script>
	<script src="js/js-library/twinlight.js"></script>
    <script src="js/script.js"></script>
     <script src="js/common.js"></script> -->

 <!--  </body>


</html> -->
<?php require './footer.php' ?>