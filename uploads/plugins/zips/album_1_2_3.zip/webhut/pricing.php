<?php require './Config.php'; ?>
<!--header-->
<?php require './header.php'; ?>

<?php 
    error_reporting(0);
    include("Database.php");

    //Select all plugins for user section

    $result = mysqli_query($conn, "SELECT * from crm_headings");
    
    $options = array();
    $headings = array();
    //Getting options 
    while($heading = mysqli_fetch_assoc($result)){
        
        $data = mysqli_query($conn, "SELECT * from crm_options where heading_id=".$heading['heading_id']);
        
        $temp = array();
        while($a = mysqli_fetch_assoc($data)){
            $temp[] = $a;
        }
        $options[$heading['heading_id']] = $temp;
        $headings[] = $heading;
    }

    //$result = (mysqli_query($conn, "SELECT * from crm_items Order By rate DESC"));    
    $result = (mysqli_query($conn, "SELECT * from crm_items "));    
    // Fetch the data and store it in an array
    $items = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $items[] = $row;
    }
     // echo"<pre>";print_r($items);die;


    // CODE FOR DISPALY THE ANNOUNCEMENT
    $result = (mysqli_query($conn, "SELECT `setting_value` from `crm_settings` WHERE `setting_name`='timezone'"));
    $row = mysqli_fetch_assoc($result);
    $timezoneSetting = $row["setting_value"];
    
    $d = DateTime::createFromFormat("Y-m-d H:i:s", date("Y-m-d H:i:s"));
    $d->setTimeZone(new DateTimeZone("UTC"));
    $d = $d->format("Y-m-d H:i:s");

    $timeZone = new DateTimeZone($timezoneSetting);
    $dateTime = new DateTime("now", $timeZone);
    $timeZone = $timeZone->getOffset($dateTime);

    $now = date("Y-m-d H:i:s", strtotime($d) + $timeZone); 
    
    $announcements = (mysqli_query($conn, "SELECT * from crm_announcements WHERE start_date<='$now' AND end_date>='$now' AND deleted = 0"));
    $annouce = array();
    while ($row = mysqli_fetch_assoc($announcements)) {
        $annouce[] = $row;
    }
    // CODE FOR DISPALY THE ANNOUNCEMENT

 ?>

<!--<div class="py-1">
    <div class="container">
        <div class="text-center">
            <h1 class="mb-0">Pricing</h1>
        </div>
    </div>
</div>-->


<div id="pricing" class="bg_light co_stats pricing-section">
    <div class="announcement-div">
            <?php
            foreach ($annouce as $announcement) {
                ?>
                <div id="<?php echo "announcement-$announcement->id"; ?>" class="alert alert-danger">
                <h5 style="color:red;margin-top:0px;padding-top:0px">Announcement</h5>
                <i data-feather="volume-2" class="icon-18 mr10"></i>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-volume-2 icon-18 mr10"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg> 
                    <a style = "color: black;font-weight: bold;" href="store-admin/index.php/announcements" style="color:Red"><?php echo $announcement['title'];?></a>
                    <div style="color: black;
                        padding-left: 55px;
                        font-size: 14px;
                    " >
                        <?php echo $announcement['description'];?>
                    </div>
                </div>
                <?php
            }
            ?>
    </div>
    <div>&nbsp;</div>
    <div class="container-fluid">
        <div class="text-center">
            <h1 class="display_7 pure_white">Choose your plan</h1>
            <div class="price-btn" style="display: block;"> 
                <a href="javascript:void(0);" id="monthly" class="price-btn-bg btn btn-xl btn-outline-light my-2 mx-2">Monthly Fee</a>
                <a href="javascript:void(0);" id="one-time" class="btn btn-xl btn-outline-light my-2 mx-2">One Time Fee</a>
            </div>
        </div>


        <div id="monthly-section">
            <div class="row text-center mb-5">
                <div class="col-lg-12 col-md-12">
                    <div class="price-btn">
                        <p class="white_text mt-3 mb-0">Host and Manage your Website on our Servers for a Monthly Fee!</p>
                        <p class="white_text ">Your Website will Automatically Install and Set Up in Seconds!</p>
                    </div>
                </div>
            </div>

            <div class="row">

                <!-- card 1 -->
                <?php foreach( $items as $item){ 
                    if($item['id'] != 6){
                ?>

                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="card pricing price-box-height">
                            <div class="card-body">
                                <div class="mb-3">
                                    <h4><?php echo $item['title'] ?></h4>
                                    <h5 class="card-title mb-0">$<?php echo $item['rate']; ?></h5>
                                    <h3 class="mb-0"><b>A Month</b></h3>
                                    <small>(1 domain)</small>
                                </div>
                                <div class="card-text">
                                    <ul class="list-unstyled">
                                        <!-- Add this within your loop -->
                                    <li>
                                        <span class="item-description-short"><?php echo substr($item['description'], 0, 200) ?></span>
                                        <span class="item-description-full" style="display: none;"><?php echo ($item['description']) ?></span>
                                        <br><a href="#" class="read-more-link" style="color:blue;">Read More</a>
                                    </li>
                                    <!-- <div class="read-more-section" style="display: none;">
                                        <?php echo ($item['description']) ?>
                                    </div> -->


                                    </ul>
                                </div> 
                                <td class="text-center">
                                    <a href="store-admin/index.php/items/pricing_add_to_cart/<?php echo $item['id']?>" class="btn btn-xs btn-info text-white item-add-to-cart-btn p15 w100p pricing-btn" disabled="disabled"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a>
                                </td>
                            </div>
                        </div>
                    </div>
                <?php }} ?>
               

            </div>


            <div class="comparison-table-section ">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th colspan="1" class="first-price-bg"></th>
                                <?php foreach( $items as $item){ 
                                    if($item['id'] != 6){
                                ?>
                                <th><?php echo $item['title'] ?>
                                    <br>$<?php echo number_format($item['rate'], 0, ".", ",") ?><br>
                                    <span class="span-month">A Month</span>
                                </th>
                                <?php }} ?>
                               <!--  <th>Pro
                                    <br>$298<br>
                                    <span class="span-month">A Month</span>
                                </th>
                                <th>Deluxe
                                    <br>$398<br>
                                    <span class="span-month">A Month</span>
                                </th>
                                <th>Ultimate
                                    <br>$1609<br>
                                    <span class="span-month">A Month</span>
                                </th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($headings as $heading) { ?>
                                <tr class="heading-table">
                                    <td><?php echo $heading['title']; ?></td>
                                    <?php if($heading['heading_id'] == 1){ ?>
                                        <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/1" class="btn align-middle btn-primary my-2 my-lg-0 table-subscribe-button"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a></td>
                                        <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/2" class="btn align-middle btn-primary my-2 my-lg-0 table-subscribe-button"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a></td>
                                        <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/3" class="btn align-middle btn-primary my-2 my-lg-0 table-subscribe-button"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a></td>
                                        <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/4" class="btn align-middle btn-primary my-2 my-lg-0 table-subscribe-button"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;&nbsp;Buy Now</a></td>
                                     <?php }else{ ?>
                                        <td><i class="fa fa-close"></i></td>
                                        <td><i class="fa fa-close"></i></td>
                                        <td><i class="fa fa-close"></i></td>
                                        <td><i class="fa fa-close"></i></td>
                                     <?php } ?>
                                </tr>

                                <?php foreach( $options[$heading['heading_id']] as $option){ ?>
                                     <tr>
                                        <td><?php echo $option['title'] ?></td>
                                        <td><i class="fa fa-<?php echo ($option['plan_1']==1?'check':'close') ?>"></i>
                                        </td>
                                        <td><i class="fa fa-<?php echo ($option['plan_2']==1?'check':'close') ?>"></i>
                                        </td>
                                        <td><i class="fa fa-<?php echo ($option['plan_3']==1?'check':'close') ?>"></i>
                                        </td>
                                        <td><i class="fa fa-<?php echo ($option['plan_4']==1?'check':'close') ?>"></i>
                                        </td>
                                    </tr>
                                 <?php } ?>   
                            <?php } ?>
                           
                           <!--  <tr>
                                <td>30 day support</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>60 day support</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>All Paid Plugins + 1 Theme</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Free Installation Services ($99)</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>One Year free updates</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>One time payment</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Instant download</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Source code access</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr class="heading-table">
                                <td>Code Features</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                            </tr>
                            <tr>
                                <td>Activity Feeds</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>User Profile</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Frinds</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>User Roles</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Layout Editer</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>

                            <tr class="heading-table">
                                <td>Localization</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                            </tr>

                            <tr>
                                <td>Multilingual</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Right-to-Left</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>3rd Party Translations</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr class="heading-table">
                                <td>Apps</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                            </tr>
                            <tr>
                                <td>REST API Library</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>IOS App or Android App License</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>IOS App and Android App License</td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-close"></i></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr> -->
                        </tbody>

                        <tfoot>

                        </tfoot>

                    </table>
                </div>
            </div>
        </div>



        <div id="one-time-section">
            <div class="row text-center mb-5">
                <div class="col-lg-12 col-md-12">
                    <div class="price-btn"> 
                        <p class="white_text mt-3 mb-0">Host, Manage, setup, and install your website on your own server for a one time fee</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>MooSocial License</h4>
                                <h5 class="card-title mb-0">$199</h5>
                                <h3 class="mb-0"><b>One-time-fee</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>3o Day fee support</li>
                                    <li>Include all Core Features and Core Plugin: Blog, Photo, Video, Topics, Groups, Events</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>You can buy mooSocial license now then get the apps in combo packages later here</li>
                                </ul>
                            </div> 

                            <a href="store-admin/index.php/items/pricing_add_to_cart/1" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label><input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span></label>
                                </div>
                                <div class="bottom-link"> 
                                    <a href="#" class="see-included">Installation Service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Pro</h4>
                                <h5 class="card-title mb-0">$308</h5>
                                <h3 class="mb-0"><b>One-time-fee</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>One mooSocial License ($99)</li>
                                    <select class="form-control">
                                        <option value="a">Android Licence ($199)</option>
                                        <option value="i">IOS Licence ($199)</option>
                                    </select>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li>60-days free support</li>
                                </ul>
                            </div>
                            <a href="store-admin/index.php/items/pricing_add_to_cart/2" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label>
                                        <input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span>
                                    </label>
                                </div>
                                <div class="bottom-link"> 
                                    <a href="#" class="see-included">
                                        Installation Service
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Deluxe</h4>
                                <h5 class="card-title mb-0">$452</h5>
                                <h3 class="mb-0"><b>One-time-fee</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>Free mooSocial Licence ($99)</li>
                                    <li>Android and IOS Licence ($398)</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li>60-days free support</li>
                                </ul>
                            </div> 
                            <a href="store-admin/index.php/items/pricing_add_to_cart/3" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="checkbox">
                                    <label>
                                        <input id="checkbox-license-installation" type="checkbox">
                                        <span class="ml-2">Installation Service (+$39)</span>
                                    </label>
                                </div>
                                <div class="bottom-link"> 
                                    <a href="#" class="see-included">Installation Service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card pricing">
                        <div class="card-body">
                            <div class="mb-3">
                                <h4>Ultimate</h4>
                                <h5 class="card-title mb-0">$2569</h5>
                                <h3 class="mb-0"><b>One-time-fee</b></h3>
                                <small>(1 domain)</small>
                            </div>
                            <div class="card-text">
                                <ul class="list-unstyled">
                                    <li>Free mooSocial Licence ($99)</li>
                                    <li>Android and IOS Licence ($398)</li>
                                    <li>Full Source Code</li>
                                    <li>White-label. Customizable</li>
                                    <li>REST API Library</li>
                                    <li>12 Months Update Subscription</li>
                                    <li class="bottom-link" data-toggle="collapse" data-target="#more">
                                        <a href="javascript:Void(0);">Read More</a>
                                    </li>
                                    <div id="more" class="collapse">
                                        <li>All Paid Plugins + 1 Theme</li>
                                        <li>Free Installation Service ($99)</li>
                                        <li>60-days free support</li>
                                        <select class="form-control">
                                            <option value="">mooSpace Theme</option>
                                            <option value="">mooOrigin Landing Page</option>
                                            <option value="">The Mommy &amp; Baby Theme</option>
                                            <option value="">mooPinterest Theme</option>
                                            <option value="">mooTimline Theme</option>
                                            <option value="">mooTube Background Theme</option>
                                            <option value="">mooX Job Theme</option>
                                            <option value="">mooX Theme</option>
                                            <option value="">mooUniversity Theme</option>
                                            <option value="">mooCooking Theme</option>
                                            <option value="">mooSocio Theme</option>
                                            <option value="">mooSport / Fancenter Theme</option>
                                            <option value="">mooInsider Theme</option>
                                            <option value="">DatingIsArt Theme</option>
                                            <option value="">RallyUP Theme</option>
                                            <option value="">Petlover Theme</option>
                                            <option value="">mooPlus (Google Plus Inspired Theme)</option>
                                            <option selected="selected" value="">mooBook (Facebook Inspired Theme)</option>
                                        </select>
                                    </div>
                                </ul>
                            </div> 
                            <a href="store-admin/index.php/items/pricing_add_to_cart/4" class="btn btn-xl btn-outline-light mt-1">Buy Now</a>
                            <div class="price-bottom my-2">
                                <div class="bottom-link"> 
                                    <a href="#" class="see-included"> View Demo</a>
                                </div>
                                <div class="bottom-link"> 
                                    <a href="#" class="see-included">Installation Service </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="comparison-table-section">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th colspan="1"></th>
                                <th>License
                                    <br>$99<br>
                                    <span class="span-month">One Time Fee</span>
                                </th>
                                <th>Pro
                                    <br>$298<br>
                                    <span class="span-month">One Time Fee</span>
                                </th>
                                <th>Deluxe
                                    <br>$398<br>
                                    <span class="span-month">One Time Fee</span>
                                </th>
                                <th>Ultimate
                                    <br>$1609<br>
                                    <span class="span-month">One Time Fee</span>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="heading-table">
                                <td>Our guarantee</td>
                                <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/1" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/2" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/3" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/4" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                            </tr>
                            <tr>
                                <td>30 day support</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>60 day support</td>
                                <td></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>All Paid Plugins + 1 Theme</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Free Installation Services ($99)</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>One Year free updates</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>One time payment</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Instant download</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Source code access</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr class="heading-table">
                                <td>Code Features</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Activity Feeds</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>User Profile</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Frinds</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>User Roles</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Layout Editer</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>

                            <tr class="heading-table">
                                <td>Localization</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>

                            <tr>
                                <td>Multilingual</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Right-to-Left</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>3rd Party Translations</td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr class="heading-table">
                                <td>Apps</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>REST API Library</td>
                                <td></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>IOS App or Android App License</td>
                                <td></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>IOS App and Android App License</td>
                                <td></td>
                                <td></td>
                                <td><i class="fa fa-check"></i>
                                </td>
                                <td><i class="fa fa-check"></i>
                                </td>
                            </tr>
                        </tbody>

                        <tfoot>
                            <tr>
                                <th colspan="1"></th>
                                <th>License
                                    <br>$99<br>
                                    <span class="span-month">One Time Fee</span>
                                </th>
                                <th>Pro
                                    <br>$298<br>
                                    <span class="span-month">One Time Fee</span>
                                </th>
                                <th>Deluxe
                                    <br>$398<br>
                                    <span class="span-month">One Time Fee</span>
                                </th>
                                <th>Ultimate
                                    <br>$1609<br>
                                    <span class="span-month">One Time Fee</span>
                                </th>
                            </tr>

                            <tr class="heading-table">
                                <td></td>
                                <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/1" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/2" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/3" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                                <td class="text-center"><a href="store-admin/index.php/items/pricing_add_to_cart/4" class="btn align-middle btn-primary my-2 my-lg-0">Buy Now</a></td>
                            </tr>
                        </tfoot>

                    </table>
                </div>
            </div>

        </div>


    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


 
<!-- Include SweetAlert library if not already included -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Function to show the full description and trigger SWAL
    function showFullDescription(item) {
        // Toggle the display of the short and full descriptions
        var shortDescription = item.querySelector('.item-description-short');
        var fullDescription = item.querySelector('.item-description-full');
        // shortDescription.style.display = 'none';
        // fullDescription.style.display = 'inline';

        // Trigger SWAL popup
        Swal.fire({
            title: 'Full Description',
            text: fullDescription.innerText,
            icon: 'info',
            confirmButtonText: 'Close'
        });
    }

    // Attach click event to all "Read More" links
    var readMoreLinks = document.querySelectorAll('.read-more-link');
    readMoreLinks.forEach(function(link) {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            var item = event.target.parentElement;
            showFullDescription(item);
        });
    });
</script>
<style>
    .announcement-div::-webkit-scrollbar {
        display: none;
    }
    .announcement-div {
        width: 100%;
        overflow-x: hidden;
        overflow-y: scroll;
        max-height: 170px;
        text-align: left;
    }
    svg:not(.gantt) {
        margin-top: -3px;
        pointer-events: none;
    }

    .icon-18 {
        width: 18px;
        height: 18px; 
    }

    .mr10 {
        margin-right: 10px; 
    }   

    img,
    svg {
        vertical-align: middle;
    }
</style>





<?php require './footer.php' ?>


