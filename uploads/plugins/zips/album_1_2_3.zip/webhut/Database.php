<?php
// Database connection
$servername = 'localhost';
$username = 'root'; // webhut96_subscription
$password = ''; // subscription@2023
$dbname = 'webhut96_subscription';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
