<?php require './Config.php'; ?>
<!--header-->
<?php require './header.php'; ?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<?php 
    error_reporting(0);
    // include("Database.php");

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://webhut.net/webhut-parent-community/index.php/sitestoreproduct/product/get-plugin-list");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if(curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    } else {
        $data = json_decode($response, true);
        // print_r($data);
    }
    curl_close($ch);
// die;
 ?>
<div style="min-height:calc(100vh - 530px);padding: 2rem;" >
  
<div class="title black" >Addons</div>

<div>

    <?php foreach ($data as $value): ?>

        <div class="plugin_con" onclick="this.querySelector('#redirectLink').click()">
            <div class="plugin_con_image" style="background-image: url(<?php echo $value['photo']; ?>);" ></div>
            <div class="plugin_con_info">
                <div class="bold black" ><a id="redirectLink" href="<?php echo $value['url']."?showInfo=1"; ?>"><?php echo $value['title']; ?></a></div>
                <div><?php echo $value['body']; ?></div>
            </div>
            <div class="plugin_con_price bold black">
                <!-- <span style="margin-top:-2px;" >$</span> -->
                    $<?php echo $value['price']; ?>
                </div>
            <div class="plugin_con_action bold link" style="display:none;">
                <a href="<?php echo $value['url']; ?>">Buy now</a>
            </div>
        </div>

    <?php endforeach;?>

</div>



</div>
<?php require './footer.php' ?>

<style type="text/css">
    *{
        font-family:'Raleway', sans-serif;
        color: #000;
    }
    .title{
        font-size: 36px;
        font-weight: bold;
        margin-top: 20px;
        margin-bottom: 10px;
    }
    .plugin_con {
        border-top: 1px solid #dfdfdf;
        display: flex;
        gap: 10px;
        padding: 15px 0;
	flex-wrap: wrap;
	cursor: pointer;
	transition:1s;
    }
    .plugin_con_image{
        height: 150px;
        width: 150px;
        background-size: contain;
        background-position: center;
        background-repeat: no-repeat;
    }
    .plugin_con_info{
        flex: 1;
	min-width: 300px;
    }
    .plugin_con_price ,.plugin_con_action{
        display: flex;
        padding: 0 10px;
        justify-content: center;
        align-items: center;
        border-left: 1px solid #dfdfdf;
        width: 150px;
    }
    .plugin_con_price{
        font-size: 20px;
        vertical-align: baseline;
    }
    .bold{
        font-weight: bold;
    }
    .link * {
        color: #189fc9 !important;
        cursor: pointer;
    }    
    .black *{
        color: #000 !important;
    }
    .plugin_con:hover {
    	background: linear-gradient(-90deg, #8be0fc38, transparent);
    	border-radius: 0 10px 10px 0;
    }

</style>