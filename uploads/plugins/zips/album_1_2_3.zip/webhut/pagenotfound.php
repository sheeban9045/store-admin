
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<style type="text/css">
	body{
		margin: 0;
		padding: 0;
	}
	/*======================
	    404 page
	=======================*/


	.page_404{ padding:40px 0; background:#fff; font-family: 'Arvo', serif;
	}

	.page_404  img{ width:100%;}

	.four_zero_four_bg{
	 
	 background-image: url(https://cdn.dribbble.com/users/285475/screenshots/2083086/dribbble_1.gif);
	    height: 400px;
	    background-position: center;
	 }
	 
	 
	 .four_zero_four_bg h1{
	 font-size:80px;
	 }
	 
	  .four_zero_four_bg h3{
				 font-size:80px;
				 }
				 
				 .link_404{			 
		color: #fff!important;
	    padding: 10px 20px;
	    background: #39ac31;
	    margin: 20px 0;
	    display: inline-block;}
		.contant_box_404{ margin-top:-50px;}
	</style>
</head>
<body>
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-9">
			<section class="page_404">
				<div class="container">
					<div class="row">	
					<div class="col-sm-12 ">
					<div class="col-sm-10 col-sm-offset-1  text-center">
					<div class="four_zero_four_bg">
						<h1 class="text-center ">404</h1>
					
					
					</div>
					
					<div class="contant_box_404">
					<h3 class="h2">
					Look like you're lost
					</h3>
					
					<p>the page you are looking for not avaible!</p>
					
					<a href="pricing.php" class="link_404">Click Here To Purchase A Plan</a>
				</div>
					</div>
					</div>
					</div>
				</div>
			</section>
		</div>
	</div>
	
</body>
</html>

