
<?php 
$plugin_data = $this->data['pluginlist'];

 ?>
<div id="page-content" class="page-wrapper clearfix">
    <div class="card clearfix">

<div id="page-content" class="page-wrapper clearfix">
<!-- <form action="app\Config\Database.php" method="post"> -->
    <input type="submit" name="vehicle2" id="vehicle2">
    <div class="card">
<center><h3>Plugins List According to Subscription Plans</h3></center><br>
<div class="card">
<table>
    <h5>Subscription Plan - Moo Social </h5>
    <br>
  <tr>
    <th>Checkboxes</th>
    <th>Plugins list</th>
    <th>Subscrption Plans</th>
  </tr>

  <?php  foreach ($plugin_data as  $value) {
    // echo $value->plugin_name;
    if ($value->plan_id == 1) {
   
    ?>
  <tr>
   <td>
  
       <img src="\community-subscription\store-admin\assets\images\enabled1.png" >


        <img src="\community-subscription\store-admin\assets\images\enabled0.png" >
        
        
</td>
    <td><?php echo $value->plugin_name; ?></td>
    <td>Moo Social</td>
  </tr>
  <?php } } ?>

</table>


    </div>
<br>
<div class="card">
<table>
    <h5>Subscription Plan - pro </h5>
    <br>
  <tr>
    <th>Checkboxes</th>
    <th>Plugins list</th>
    <th>Subscrption Plans</th>
  </tr>

  <?php  foreach ($plugin_data as  $value) {
    // echo $value->plugin_name;
    if ($value->plan_id == 2) {
   
    ?>
  <tr>
   <td>
  
       <img src="\community-subscription\store-admin\assets\images\enabled1.png" >


        <img src="\community-subscription\store-admin\assets\images\enabled0.png" >
        
        
</td>
    <td><?php echo $value->plugin_name; ?></td>
    <td>pro</td>
  </tr>
  <?php } } ?>

</table>


    </div>


<br>
<div class="card">
<table>
    <h5>Subscription Plan - Deluxe </h5>
    <br>
  <tr>
    <th>Checkboxes</th>
    <th>Plugins list</th>
    <th>Subscrption Plans</th>
  </tr>

  <?php  foreach ($plugin_data as  $value) {
    // echo $value->plugin_name;
    if ($value->plan_id == 3) {
   
    ?>
  <tr>
   <td>
  
       <img src="\community-subscription\store-admin\assets\images\enabled1.png" >


        <img src="\community-subscription\store-admin\assets\images\enabled0.png" >
        
        
</td>
    <td><?php echo $value->plugin_name; ?></td>
    <td>Deluxe</td>
  </tr>
  <?php } } ?>

</table>


    </div>

<br>
<div class="card">
<table>
    <h5>Subscription Plan - Ultimate</h5>
    <br>
  <tr>
    <th>Checkboxes</th>
    <th>Plugins list</th>
    <th>Subscrption Plans</th>
  </tr>

  <?php  foreach ($plugin_data as  $value) {
    // echo $value->plugin_name;
    if ($value->plan_id == 4) {
   
    ?>
  <tr>
   <td>
  
       <img src="\community-subscription\store-admin\assets\images\enabled1.png" >


        <img src="\community-subscription\store-admin\assets\images\enabled0.png" >
        
        
</td>
    <td><?php echo $value->plugin_name; ?></td>
    <td>Ultimate</td>
  </tr>
  <?php } } ?>

</table>


    </div>


    
   
<!-- </form> -->


        <div class="page-title clearfix">
            <h1> <?php echo app_lang(''); ?></h1>
            <div class="title-button-group">
                <!-- <?php echo anchor(get_uri("items/grid_view"), "<i data-feather='plus-circle' class='icon-16'></i> " . app_lang('add_order'), array("class" => "btn btn-default", "id" => "add-order-btn")); ?>  -->
            </div>
        </div>
        <div class="table-responsive">
            <table id="order-table" class="display" cellspacing="0" width="100%">            
            </table>
        </div>
    </div>
</div>





        <!-- <ul id="order-tabs" data-bs-toggle="ajax-tab" class="nav nav-tabs bg-white title" role="tablist">
            <li class="title-tab"><h4 class="pl15 pt10 pr15"><?php echo app_lang('orders'); ?></h4></li>
            <li><a id="monthly-order-button"  role="presentation" href="javascript:;" data-bs-target="#monthly-orders" onclick="changeDateRange('monthly')"><?php echo app_lang("monthly"); ?></a></li>
            <li><a role="presentation" href="<?php echo_uri("orders/yearly/"); ?>" data-bs-target="#yearly-orders" onclick="changeDateRange('yearly')"><?php echo app_lang('yearly'); ?></a></li>
              <li><a role="presentation" href="<?php echo_uri("orders/production/"); ?>" data-bs-target="#production-orders" onclick="changeDateRange('production')"><?php echo app_lang('production'); ?></a></li>




            <div class="tab-title clearfix no-border">

                <div class="title-button-group">
                    <?php echo js_anchor("<i data-feather='plus-circle' class='icon-16'></i> " . app_lang('add_order'), array("class" => "btn btn-default", "id" => "add-order-btn")); ?>           
                </div>  


               

                <?php if( !empty($order_statuses) ): ?>
                    <div class="title-button-group">
                        <?php echo js_anchor( app_lang('apply'), array("class" => "btn btn-default", "id" => "add-order-btn", "onclick" => "changeOredrStatus()")); ?>   
                                
                    </div>
                    

                      <input type="checkbox" onclick='mycheck(this)' value="Select All" class="btn btn-default", id = "add-order-btn" />  
                      <div class="btn btn-default">
                        
                         <select id="order_status" style="width: 125px; border: none;">
                            <option value=""><?php echo app_lang('bulk_action'); ?></option>
                            <?php  foreach($order_statuses as $order_status): ?>
                                    <option value="<?php echo $order_status->id; ?>"><?php echo $order_status->title; ?></option>
                            <?php endforeach; ?>
                          </select>

                  
          
                          

                    </div>  
                <?php endif; ?> 

        </ul>
 -->

        <!-- <div class="tab-content">
            <div role="tabpanel" class="tab-pane fade" id="monthly-orders">
                
                <div class="table-responsive">
                    <table id="monthly-order-table" class="display" cellspacing="0" width="100%"> 
                    </table>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane fade" id="yearly-orders"></div>
            <div role="tabpanel" class="tab-pane fade" id="production-orders"></div>
        </div>   -->      
    </div>
</div>

<!-- <script type="text/javascript">
    var default_date_range = 'monthly';
  = $("#order_status option:selected").val();

        $('input:checkbox[name=' + default_date_range + '_checkbox_order_ids]').each(function() 
        {
            if($(this).is(':checked')) {

                var order_id = $(this).val();
                if( order_id && current_order_status ) {
                    should_refresh = 1;

                    $.ajax({
                   
                        dataType: 'json',
                        data: {value: current_order_status},
                        success: function (result) {
                            
                        }
                    });
                }
            }
        });


        if( should_refresh == 1 )
            window.location.reload();
    }


    function changeDateRange(value) {
        default_date_range = value;
    }

        function mycheck(main)
        { 
            all = document.getElementsByName(default_date_range + '_checkbox_order_ids');  
            for(var i=0; i<all.length; i++){

                all[i].checked = main.checked;
            }
            
        }

</script> -->
<!-- <script>
    function changeImage(){
   var image = document.getElementById('myImage');
   if (image.src.match("s"))
   {image.src ="enabled0.png";}
   else
    {image.src ="enabled1.png";}  
}
</script> -->



