<?php 
$plugin_data = $this->data['pluginlist'];
 ?>
<div id="page-content" class="page-wrapper clearfix">
    <div class="card clearfix">

<div id="page-content" class="page-wrapper clearfix">

    
    <div class="card">
<center><h3>Plugins List According to Subscription Plans</h3></center><br>
<div class="card">
<table>
    <h5>Subscription Plan - Moo Social </h5>
    <br>
  <tr>
    <th>Sr no</th>
    <th>Plugins list</th>   
  </tr>

  <?php $i=1;  foreach ($plugin_data as  $value) {

 if ($value->plan_id==1 && $value->status==1) { ?>
  <tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $value->plugin_name; ?></td>
    <?php $i++;  ?>  
  </tr>
  <?php } } ?>

</table>


    </div>
<br>
<div class="card">
<table>
    <h5>Subscription Plan - pro </h5>
    <br>
    <tr>
    <th>Sr no</th>
    <th>Plugins list</th>   
  </tr>

  <?php $i=1;  foreach ($plugin_data as  $value) {

 if ($value->plan_id==2 && $value->status==1) { ?>
  <tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $value->plugin_name; ?></td>
    <?php $i++;  ?>  
  </tr>
  <?php } } ?>

</table>


    </div>


<br>
<div class="card">
<table>
    <h5>Subscription Plan - Deluxe </h5>
    <br>
    <tr>
    <th>Sr no</th>
    <th>Plugins list</th>   
  </tr>

  <?php $i=1;  foreach ($plugin_data as  $value) {

 if ($value->plan_id==3 && $value->status==1) { ?>
  <tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $value->plugin_name; ?></td>
    <?php $i++;  ?>  
  </tr>
  <?php } } ?>

</table>


    </div>

<br>
<div class="card">
<table>
    <h5>Subscription Plan - Ultimate</h5>
    <br>
    <tr>
    <th>Sr no</th>
    <th>Plugins list</th>   
  </tr>

  <?php $i=1;  foreach ($plugin_data as  $value) {

 if ($value->plan_id==4 && $value->status==1) { ?>
  <tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $value->plugin_name; ?></td>
    <?php $i++;  ?>  
  </tr>
  <?php } } ?>

</table>


    </div>


        <div class="page-title clearfix">
            <h1> <?php echo app_lang(''); ?></h1>
            <div class="title-button-group">
                <!-- <?php echo anchor(get_uri("items/grid_view"), "<i data-feather='plus-circle' class='icon-16'></i> " . app_lang('add_order'), array("class" => "btn btn-default", "id" => "add-order-btn")); ?>  -->
            </div>
        </div>
        <div class="table-responsive">
            <table id="order-table" class="display" cellspacing="0" width="100%">            
            </table>
        </div>
    </div>
</div>





<!-- <script type="text/javascript">
    $(document).ready(function () {
        $("#order-table").appTable({
            source: '<?php echo_uri("plugin/order_list_data_of_client/" . $client_id) ?>',
            order: [[0, "desc"]],
            filterDropdown: [<?php echo $custom_field_filters; ?>],
            columns: [
                {title: "<?php echo ("checkboxes") ?>", "class": "w20p"},
                
             {title: "<?php echo ("plugins list") ?>", "iDataSort": 2, "class": "w20p"},
                {title: "<?php echo ("subscription plan") ?>", "iDataSort": 2, "class": "w20p"},
           
            ],
            summation: []
        });
    });
</script> -->